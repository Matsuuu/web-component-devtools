# Nydus

Nydus is a tool/library built for orchestrating communication across different layers of
Chrome DevTools. It attemps to synchronize the layers and make it easier to pass messages around.

Nydus is a part of Web Component DevTools, and might be published as it's own package later down the line.
