import { LitWithCem } from './src/LitWithCem.js';

window.customElements.define('lit-with-cem', LitWithCem);
