import { LitNoCem } from './src/LitNoCem.js';

window.customElements.define('lit-no-cem', LitNoCem);
