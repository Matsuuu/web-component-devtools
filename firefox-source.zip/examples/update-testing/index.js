export { UpdateTesting } from './src/UpdateTesting.js';
