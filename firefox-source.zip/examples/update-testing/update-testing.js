import { UpdateTesting } from './src/UpdateTesting.js';

window.customElements.define('update-testing', UpdateTesting);
