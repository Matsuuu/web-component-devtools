import { ListItem } from './src/ListItem.js';

window.customElements.define('list-item', ListItem);
