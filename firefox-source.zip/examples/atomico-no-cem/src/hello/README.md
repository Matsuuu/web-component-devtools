# atomico-brand

## Properties

| Property | Types  | Description        |
| -------- | ------ | ------------------ |
| message  | String | Message to display |

## Events

| Type | Detail | Description |
| ---- | ------ | ----------- |
| -    | -      | -           |

## Slots

| Slot | Types | Description    |
| ---- | ----- | -------------- |
| -    | -     | Insert content |

## Custom properties

| Property         | Types | Description             |
| ---------------- | ----- | ----------------------- |
| --hello-shadow-1 | color | Color 1 for text-shadow |
| --hello-shadow-2 | color | Color 2 for text-shadow |
