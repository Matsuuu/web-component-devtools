import { Hello } from "./hello/hello.jsx";
import { Brand } from "./brand/brand.jsx";

customElements.define("atomico-hello", Hello);
customElements.define("atomico-brand", Brand);
