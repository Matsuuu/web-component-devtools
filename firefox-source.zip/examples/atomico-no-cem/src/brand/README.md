# atomico-brand

## Properties

| Property | types  | description     |
| -------- | ------ | --------------- |
| color    | String | Component color |
| width    | String | Component width |

## Events

| Type | Detail | Description |
| ---- | ------ | ----------- |
| -    | -      | -           |

## Slots

| slot | types | description |
| ---- | ----- | ----------- |
| -    | -     | -           |

## Custom properties

| Property | types | description |
| -------- | ----- | ----------- |
