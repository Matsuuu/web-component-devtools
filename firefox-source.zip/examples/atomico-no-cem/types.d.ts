declare module "*.css" {
  export default URL.prototype;
}
declare module "*.png" {
  export default URL.prototype;
}
declare module "*.jpg" {
  export default URL.prototype;
}
declare module "*.jpeg" {
  export default URL.prototype;
}
declare module "*.gif" {
  export default URL.prototype;
}
declare module "*.webp" {
  export default URL.prototype;
}
declare module "*.svg" {
  export default URL.prototype;
}
declare module "*.mp4" {
  export default URL.prototype;
}
declare module "*.ogg" {
  export default URL.prototype;
}
declare module "*.mp3" {
  export default URL.prototype;
}
declare module "*.wav" {
  export default URL.prototype;
}
declare module "*.flac" {
  export default URL.prototype;
}
declare module "*.aac" {
  export default URL.prototype;
}
declare module "*.woff" {
  export default URL.prototype;
}
declare module "*.woff2" {
  export default URL.prototype;
}
declare module "*.eot" {
  export default URL.prototype;
}
declare module "*.ttf" {
  export default URL.prototype;
}
declare module "*.otf" {
  export default URL.prototype;
}

declare module "*.json" {
  export default URL.prototype;
}
