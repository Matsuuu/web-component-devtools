import vite from "vite-web-test-runner-plugin";

export default {
  plugins: [vite()],
};
