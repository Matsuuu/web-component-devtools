# CONTRIBUTING

At the current moment Web Component DevTools is mainly developed by [Matsuuu](https://github.com/Matsuuu) and 
all of the large design decisions go through them.

Contributions, be it in a form of an idea, bug report, feature request or anything else are always welcome!
