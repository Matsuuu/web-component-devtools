/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$3=window.ShadowRoot&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,e$3=Symbol();class s$5{constructor(t,s){if(s!==e$3)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t;}get styleSheet(){return t$3&&void 0===this.t&&(this.t=new CSSStyleSheet,this.t.replaceSync(this.cssText)),this.t}toString(){return this.cssText}}const n$3=new Map,o$3=t=>{let o=n$3.get(t);return void 0===o&&n$3.set(t,o=new s$5(t,e$3)),o},r$2=t=>o$3("string"==typeof t?t:t+""),i$3=(t,...e)=>{const n=1===t.length?t[0]:e.reduce(((e,n,o)=>e+(t=>{if(t instanceof s$5)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(n)+t[o+1]),t[0]);return o$3(n)},S$1=(e,s)=>{t$3?e.adoptedStyleSheets=s.map((t=>t instanceof CSSStyleSheet?t:t.styleSheet)):s.forEach((t=>{const s=document.createElement("style");s.textContent=t.cssText,e.appendChild(s);}));},u$3=t$3?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const s of t.cssRules)e+=s.cssText;return r$2(e)})(t):t;

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var s$4,e$2,h$2,r$1;const o$2={toAttribute(t,i){switch(i){case Boolean:t=t?"":null;break;case Object:case Array:t=null==t?t:JSON.stringify(t);}return t},fromAttribute(t,i){let s=t;switch(i){case Boolean:s=null!==t;break;case Number:s=null===t?null:Number(t);break;case Object:case Array:try{s=JSON.parse(t);}catch(t){s=null;}}return s}},n$2=(t,i)=>i!==t&&(i==i||t==t),l$3={attribute:!0,type:String,converter:o$2,reflect:!1,hasChanged:n$2};class a$3 extends HTMLElement{constructor(){super(),this.Πi=new Map,this.Πo=void 0,this.Πl=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this.Πh=null,this.u();}static addInitializer(t){var i;null!==(i=this.v)&&void 0!==i||(this.v=[]),this.v.push(t);}static get observedAttributes(){this.finalize();const t=[];return this.elementProperties.forEach(((i,s)=>{const e=this.Πp(s,i);void 0!==e&&(this.Πm.set(e,s),t.push(e));})),t}static createProperty(t,i=l$3){if(i.state&&(i.attribute=!1),this.finalize(),this.elementProperties.set(t,i),!i.noAccessor&&!this.prototype.hasOwnProperty(t)){const s="symbol"==typeof t?Symbol():"__"+t,e=this.getPropertyDescriptor(t,s,i);void 0!==e&&Object.defineProperty(this.prototype,t,e);}}static getPropertyDescriptor(t,i,s){return {get(){return this[i]},set(e){const h=this[t];this[i]=e,this.requestUpdate(t,h,s);},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)||l$3}static finalize(){if(this.hasOwnProperty("finalized"))return !1;this.finalized=!0;const t=Object.getPrototypeOf(this);if(t.finalize(),this.elementProperties=new Map(t.elementProperties),this.Πm=new Map,this.hasOwnProperty("properties")){const t=this.properties,i=[...Object.getOwnPropertyNames(t),...Object.getOwnPropertySymbols(t)];for(const s of i)this.createProperty(s,t[s]);}return this.elementStyles=this.finalizeStyles(this.styles),!0}static finalizeStyles(i){const s=[];if(Array.isArray(i)){const e=new Set(i.flat(1/0).reverse());for(const i of e)s.unshift(u$3(i));}else void 0!==i&&s.push(u$3(i));return s}static Πp(t,i){const s=i.attribute;return !1===s?void 0:"string"==typeof s?s:"string"==typeof t?t.toLowerCase():void 0}u(){var t;this.Πg=new Promise((t=>this.enableUpdating=t)),this.L=new Map,this.Π_(),this.requestUpdate(),null===(t=this.constructor.v)||void 0===t||t.forEach((t=>t(this)));}addController(t){var i,s;(null!==(i=this.ΠU)&&void 0!==i?i:this.ΠU=[]).push(t),void 0!==this.renderRoot&&this.isConnected&&(null===(s=t.hostConnected)||void 0===s||s.call(t));}removeController(t){var i;null===(i=this.ΠU)||void 0===i||i.splice(this.ΠU.indexOf(t)>>>0,1);}Π_(){this.constructor.elementProperties.forEach(((t,i)=>{this.hasOwnProperty(i)&&(this.Πi.set(i,this[i]),delete this[i]);}));}createRenderRoot(){var t;const s=null!==(t=this.shadowRoot)&&void 0!==t?t:this.attachShadow(this.constructor.shadowRootOptions);return S$1(s,this.constructor.elementStyles),s}connectedCallback(){var t;void 0===this.renderRoot&&(this.renderRoot=this.createRenderRoot()),this.enableUpdating(!0),null===(t=this.ΠU)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostConnected)||void 0===i?void 0:i.call(t)})),this.Πl&&(this.Πl(),this.Πo=this.Πl=void 0);}enableUpdating(t){}disconnectedCallback(){var t;null===(t=this.ΠU)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostDisconnected)||void 0===i?void 0:i.call(t)})),this.Πo=new Promise((t=>this.Πl=t));}attributeChangedCallback(t,i,s){this.K(t,s);}Πj(t,i,s=l$3){var e,h;const r=this.constructor.Πp(t,s);if(void 0!==r&&!0===s.reflect){const n=(null!==(h=null===(e=s.converter)||void 0===e?void 0:e.toAttribute)&&void 0!==h?h:o$2.toAttribute)(i,s.type);this.Πh=t,null==n?this.removeAttribute(r):this.setAttribute(r,n),this.Πh=null;}}K(t,i){var s,e,h;const r=this.constructor,n=r.Πm.get(t);if(void 0!==n&&this.Πh!==n){const t=r.getPropertyOptions(n),l=t.converter,a=null!==(h=null!==(e=null===(s=l)||void 0===s?void 0:s.fromAttribute)&&void 0!==e?e:"function"==typeof l?l:null)&&void 0!==h?h:o$2.fromAttribute;this.Πh=n,this[n]=a(i,t.type),this.Πh=null;}}requestUpdate(t,i,s){let e=!0;void 0!==t&&(((s=s||this.constructor.getPropertyOptions(t)).hasChanged||n$2)(this[t],i)?(this.L.has(t)||this.L.set(t,i),!0===s.reflect&&this.Πh!==t&&(void 0===this.Πk&&(this.Πk=new Map),this.Πk.set(t,s))):e=!1),!this.isUpdatePending&&e&&(this.Πg=this.Πq());}async Πq(){this.isUpdatePending=!0;try{for(await this.Πg;this.Πo;)await this.Πo;}catch(t){Promise.reject(t);}const t=this.performUpdate();return null!=t&&await t,!this.isUpdatePending}performUpdate(){var t;if(!this.isUpdatePending)return;this.hasUpdated,this.Πi&&(this.Πi.forEach(((t,i)=>this[i]=t)),this.Πi=void 0);let i=!1;const s=this.L;try{i=this.shouldUpdate(s),i?(this.willUpdate(s),null===(t=this.ΠU)||void 0===t||t.forEach((t=>{var i;return null===(i=t.hostUpdate)||void 0===i?void 0:i.call(t)})),this.update(s)):this.Π$();}catch(t){throw i=!1,this.Π$(),t}i&&this.E(s);}willUpdate(t){}E(t){var i;null===(i=this.ΠU)||void 0===i||i.forEach((t=>{var i;return null===(i=t.hostUpdated)||void 0===i?void 0:i.call(t)})),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t);}Π$(){this.L=new Map,this.isUpdatePending=!1;}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this.Πg}shouldUpdate(t){return !0}update(t){void 0!==this.Πk&&(this.Πk.forEach(((t,i)=>this.Πj(i,this[i],t))),this.Πk=void 0),this.Π$();}updated(t){}firstUpdated(t){}}a$3.finalized=!0,a$3.elementProperties=new Map,a$3.elementStyles=[],a$3.shadowRootOptions={mode:"open"},null===(e$2=(s$4=globalThis).reactiveElementPlatformSupport)||void 0===e$2||e$2.call(s$4,{ReactiveElement:a$3}),(null!==(h$2=(r$1=globalThis).reactiveElementVersions)&&void 0!==h$2?h$2:r$1.reactiveElementVersions=[]).push("1.0.0-rc.2");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var t$2,i$2,s$3,e$1;const o$1=globalThis.trustedTypes,l$2=o$1?o$1.createPolicy("lit-html",{createHTML:t=>t}):void 0,n$1=`lit$${(Math.random()+"").slice(9)}$`,h$1="?"+n$1,r=`<${h$1}>`,u$2=document,c$2=(t="")=>u$2.createComment(t),d$1=t=>null===t||"object"!=typeof t&&"function"!=typeof t,v=Array.isArray,a$2=t=>{var i;return v(t)||"function"==typeof(null===(i=t)||void 0===i?void 0:i[Symbol.iterator])},f$1=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,_=/-->/g,m$1=/>/g,p=/>|[ 	\n\r](?:([^\s"'>=/]+)([ 	\n\r]*=[ 	\n\r]*(?:[^ 	\n\r"'`<>=]|("|')|))|$)/g,$=/'/g,g=/"/g,y=/^(?:script|style|textarea)$/i,b=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),T=b(1),w=Symbol.for("lit-noChange"),A=Symbol.for("lit-nothing"),P=new WeakMap,V=(t,i,s)=>{var e,o;const l=null!==(e=null==s?void 0:s.renderBefore)&&void 0!==e?e:i;let n=l._$litPart$;if(void 0===n){const t=null!==(o=null==s?void 0:s.renderBefore)&&void 0!==o?o:null;l._$litPart$=n=new C(i.insertBefore(c$2(),t),t,void 0,s);}return n.I(t),n},E=u$2.createTreeWalker(u$2,129,null,!1),M=(t,i)=>{const s=t.length-1,e=[];let o,h=2===i?"<svg>":"",u=f$1;for(let i=0;i<s;i++){const s=t[i];let l,c,d=-1,v=0;for(;v<s.length&&(u.lastIndex=v,c=u.exec(s),null!==c);)v=u.lastIndex,u===f$1?"!--"===c[1]?u=_:void 0!==c[1]?u=m$1:void 0!==c[2]?(y.test(c[2])&&(o=RegExp("</"+c[2],"g")),u=p):void 0!==c[3]&&(u=p):u===p?">"===c[0]?(u=null!=o?o:f$1,d=-1):void 0===c[1]?d=-2:(d=u.lastIndex-c[2].length,l=c[1],u=void 0===c[3]?p:'"'===c[3]?g:$):u===g||u===$?u=p:u===_||u===m$1?u=f$1:(u=p,o=void 0);const a=u===p&&t[i+1].startsWith("/>")?" ":"";h+=u===f$1?s+r:d>=0?(e.push(l),s.slice(0,d)+"$lit$"+s.slice(d)+n$1+a):s+n$1+(-2===d?(e.push(void 0),i):a);}const c=h+(t[s]||"<?>")+(2===i?"</svg>":"");return [void 0!==l$2?l$2.createHTML(c):c,e]};class N{constructor({strings:t,_$litType$:i},s){let e;this.parts=[];let l=0,r=0;const u=t.length-1,d=this.parts,[v,a]=M(t,i);if(this.el=N.createElement(v,s),E.currentNode=this.el.content,2===i){const t=this.el.content,i=t.firstChild;i.remove(),t.append(...i.childNodes);}for(;null!==(e=E.nextNode())&&d.length<u;){if(1===e.nodeType){if(e.hasAttributes()){const t=[];for(const i of e.getAttributeNames())if(i.endsWith("$lit$")||i.startsWith(n$1)){const s=a[r++];if(t.push(i),void 0!==s){const t=e.getAttribute(s.toLowerCase()+"$lit$").split(n$1),i=/([.?@])?(.*)/.exec(s);d.push({type:1,index:l,name:i[2],strings:t,ctor:"."===i[1]?I:"?"===i[1]?L:"@"===i[1]?R:H});}else d.push({type:6,index:l});}for(const i of t)e.removeAttribute(i);}if(y.test(e.tagName)){const t=e.textContent.split(n$1),i=t.length-1;if(i>0){e.textContent=o$1?o$1.emptyScript:"";for(let s=0;s<i;s++)e.append(t[s],c$2()),E.nextNode(),d.push({type:2,index:++l});e.append(t[i],c$2());}}}else if(8===e.nodeType)if(e.data===h$1)d.push({type:2,index:l});else {let t=-1;for(;-1!==(t=e.data.indexOf(n$1,t+1));)d.push({type:7,index:l}),t+=n$1.length-1;}l++;}}static createElement(t,i){const s=u$2.createElement("template");return s.innerHTML=t,s}}function S(t,i,s=t,e){var o,l,n,h;if(i===w)return i;let r=void 0!==e?null===(o=s.Σi)||void 0===o?void 0:o[e]:s.Σo;const u=d$1(i)?void 0:i._$litDirective$;return (null==r?void 0:r.constructor)!==u&&(null===(l=null==r?void 0:r.O)||void 0===l||l.call(r,!1),void 0===u?r=void 0:(r=new u(t),r.T(t,s,e)),void 0!==e?(null!==(n=(h=s).Σi)&&void 0!==n?n:h.Σi=[])[e]=r:s.Σo=r),void 0!==r&&(i=S(t,r.S(t,i.values),r,e)),i}class k{constructor(t,i){this.l=[],this.N=void 0,this.D=t,this.M=i;}u(t){var i;const{el:{content:s},parts:e}=this.D,o=(null!==(i=null==t?void 0:t.creationScope)&&void 0!==i?i:u$2).importNode(s,!0);E.currentNode=o;let l=E.nextNode(),n=0,h=0,r=e[0];for(;void 0!==r;){if(n===r.index){let i;2===r.type?i=new C(l,l.nextSibling,this,t):1===r.type?i=new r.ctor(l,r.name,r.strings,this,t):6===r.type&&(i=new z(l,this,t)),this.l.push(i),r=e[++h];}n!==(null==r?void 0:r.index)&&(l=E.nextNode(),n++);}return o}v(t){let i=0;for(const s of this.l)void 0!==s&&(void 0!==s.strings?(s.I(t,s,i),i+=s.strings.length-2):s.I(t[i])),i++;}}class C{constructor(t,i,s,e){this.type=2,this.N=void 0,this.A=t,this.B=i,this.M=s,this.options=e;}setConnected(t){var i;null===(i=this.P)||void 0===i||i.call(this,t);}get parentNode(){return this.A.parentNode}get startNode(){return this.A}get endNode(){return this.B}I(t,i=this){t=S(this,t,i),d$1(t)?t===A||null==t||""===t?(this.H!==A&&this.R(),this.H=A):t!==this.H&&t!==w&&this.m(t):void 0!==t._$litType$?this._(t):void 0!==t.nodeType?this.$(t):a$2(t)?this.g(t):this.m(t);}k(t,i=this.B){return this.A.parentNode.insertBefore(t,i)}$(t){this.H!==t&&(this.R(),this.H=this.k(t));}m(t){const i=this.A.nextSibling;null!==i&&3===i.nodeType&&(null===this.B?null===i.nextSibling:i===this.B.previousSibling)?i.data=t:this.$(u$2.createTextNode(t)),this.H=t;}_(t){var i;const{values:s,_$litType$:e}=t,o="number"==typeof e?this.C(t):(void 0===e.el&&(e.el=N.createElement(e.h,this.options)),e);if((null===(i=this.H)||void 0===i?void 0:i.D)===o)this.H.v(s);else {const t=new k(o,this),i=t.u(this.options);t.v(s),this.$(i),this.H=t;}}C(t){let i=P.get(t.strings);return void 0===i&&P.set(t.strings,i=new N(t)),i}g(t){v(this.H)||(this.H=[],this.R());const i=this.H;let s,e=0;for(const o of t)e===i.length?i.push(s=new C(this.k(c$2()),this.k(c$2()),this,this.options)):s=i[e],s.I(o),e++;e<i.length&&(this.R(s&&s.B.nextSibling,e),i.length=e);}R(t=this.A.nextSibling,i){var s;for(null===(s=this.P)||void 0===s||s.call(this,!1,!0,i);t&&t!==this.B;){const i=t.nextSibling;t.remove(),t=i;}}}class H{constructor(t,i,s,e,o){this.type=1,this.H=A,this.N=void 0,this.V=void 0,this.element=t,this.name=i,this.M=e,this.options=o,s.length>2||""!==s[0]||""!==s[1]?(this.H=Array(s.length-1).fill(A),this.strings=s):this.H=A;}get tagName(){return this.element.tagName}I(t,i=this,s,e){const o=this.strings;let l=!1;if(void 0===o)t=S(this,t,i,0),l=!d$1(t)||t!==this.H&&t!==w,l&&(this.H=t);else {const e=t;let n,h;for(t=o[0],n=0;n<o.length-1;n++)h=S(this,e[s+n],i,n),h===w&&(h=this.H[n]),l||(l=!d$1(h)||h!==this.H[n]),h===A?t=A:t!==A&&(t+=(null!=h?h:"")+o[n+1]),this.H[n]=h;}l&&!e&&this.W(t);}W(t){t===A?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,null!=t?t:"");}}class I extends H{constructor(){super(...arguments),this.type=3;}W(t){this.element[this.name]=t===A?void 0:t;}}class L extends H{constructor(){super(...arguments),this.type=4;}W(t){t&&t!==A?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name);}}class R extends H{constructor(){super(...arguments),this.type=5;}I(t,i=this){var s;if((t=null!==(s=S(this,t,i,0))&&void 0!==s?s:A)===w)return;const e=this.H,o=t===A&&e!==A||t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive,l=t!==A&&(e===A||o);o&&this.element.removeEventListener(this.name,this,e),l&&this.element.addEventListener(this.name,this,t),this.H=t;}handleEvent(t){var i,s;"function"==typeof this.H?this.H.call(null!==(s=null===(i=this.options)||void 0===i?void 0:i.host)&&void 0!==s?s:this.element,t):this.H.handleEvent(t);}}class z{constructor(t,i,s){this.element=t,this.type=6,this.N=void 0,this.V=void 0,this.M=i,this.options=s;}I(t){S(this,t);}}const Z={Z:"$lit$",U:n$1,Y:h$1,q:1,X:M,tt:k,it:a$2,st:S,et:C,ot:H,nt:L,rt:R,lt:I,ht:z};null===(i$2=(t$2=globalThis).litHtmlPlatformSupport)||void 0===i$2||i$2.call(t$2,N,C),(null!==(s$3=(e$1=globalThis).litHtmlVersions)&&void 0!==s$3?s$3:e$1.litHtmlVersions=[]).push("2.0.0-rc.3");

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */var i$1,l$1,o,s$2,n,a$1;(null!==(i$1=(a$1=globalThis).litElementVersions)&&void 0!==i$1?i$1:a$1.litElementVersions=[]).push("3.0.0-rc.2");class h extends a$3{constructor(){super(...arguments),this.renderOptions={host:this},this.Φt=void 0;}createRenderRoot(){var t,e;const r=super.createRenderRoot();return null!==(t=(e=this.renderOptions).renderBefore)&&void 0!==t||(e.renderBefore=r.firstChild),r}update(t){const r=this.render();super.update(t),this.Φt=V(r,this.renderRoot,this.renderOptions);}connectedCallback(){var t;super.connectedCallback(),null===(t=this.Φt)||void 0===t||t.setConnected(!0);}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this.Φt)||void 0===t||t.setConnected(!1);}render(){return w}}h.finalized=!0,h._$litElement$=!0,null===(o=(l$1=globalThis).litElementHydrateSupport)||void 0===o||o.call(l$1,{LitElement:h}),null===(n=(s$2=globalThis).litElementPlatformSupport)||void 0===n||n.call(s$2,{LitElement:h});

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t$1={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},i=t=>(...i)=>({_$litDirective$:t,values:i});class s$1{constructor(t){}T(t,i,s){this.Σdt=t,this.M=i,this.Σct=s;}S(t,i){return this.update(t,i)}update(t,i){return this.render(...i)}}

/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const {et:t}=Z,d=o=>void 0===o.strings,e=()=>document.createComment(""),u$1=(o,i,n)=>{var v;const l=o.A.parentNode,r=void 0===i?o.B:i.A;if(void 0===n){const i=l.insertBefore(e(),r),v=l.insertBefore(e(),r);n=new t(i,v,o,o.options);}else {const t=n.B.nextSibling,i=n.M!==o;if(i&&(null===(v=n.Q)||void 0===v||v.call(n,o),n.M=o),t!==r||i){let o=n.A;for(;o!==t;){const t=o.nextSibling;l.insertBefore(o,r),o=t;}}}return n},c$1=(o,t,i=o)=>(o.I(t,i),o),s={},f=(o,t=s)=>o.H=t,a=o=>o.H,m=o=>{var t;null===(t=o.P)||void 0===t||t.call(o,!1,!0);let i=o.A;const n=o.B.nextSibling;for(;i!==n;){const o=i.nextSibling;i.remove(),i=o;}};

/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const u=(e,s,t)=>{const r=new Map;for(let l=s;l<=t;l++)r.set(e[l],l);return r},c=i(class extends s$1{constructor(e){if(super(e),e.type!==t$1.CHILD)throw Error("repeat() can only be used in text expressions")}Mt(e,s,t){let r;void 0===t?t=s:void 0!==s&&(r=s);const l=[],o=[];let i=0;for(const s of e)l[i]=r?r(s,i):i,o[i]=t(s,i),i++;return {values:o,keys:l}}render(e,s,t){return this.Mt(e,s,t).values}update(s,[t,r,c]){var d;const p=a(s),{values:v,keys:a$1}=this.Mt(t,r,c);if(!p)return this.Pt=a$1,v;const h=null!==(d=this.Pt)&&void 0!==d?d:this.Pt=[],m$1=[];let x,y,j=0,k=p.length-1,w$1=0,b=v.length-1;for(;j<=k&&w$1<=b;)if(null===p[j])j++;else if(null===p[k])k--;else if(h[j]===a$1[w$1])m$1[w$1]=c$1(p[j],v[w$1]),j++,w$1++;else if(h[k]===a$1[b])m$1[b]=c$1(p[k],v[b]),k--,b--;else if(h[j]===a$1[b])m$1[b]=c$1(p[j],v[b]),u$1(s,m$1[b+1],p[j]),j++,b--;else if(h[k]===a$1[w$1])m$1[w$1]=c$1(p[k],v[w$1]),u$1(s,p[j],p[k]),k--,w$1++;else if(void 0===x&&(x=u(a$1,w$1,b),y=u(h,j,k)),x.has(h[j]))if(x.has(h[k])){const e=y.get(a$1[w$1]),t=void 0!==e?p[e]:null;if(null===t){const e=u$1(s,p[j]);c$1(e,v[w$1]),m$1[w$1]=e;}else m$1[w$1]=c$1(t,v[w$1]),u$1(s,p[j],t),p[e]=null;w$1++;}else m(p[k]),k--;else m(p[j]),j++;for(;w$1<=b;){const e=u$1(s,m$1[b+1]);c$1(e,v[w$1]),m$1[w$1++]=e;}for(;j<=k;){const e=p[j++];null!==e&&m(e);}return this.Pt=a$1,f(s,m$1),w}});

/**
 * @typedef {number} DevToolsMessageType
 * */

const MESSAGE_TYPE = {
    LOG: 0,
    LOG_OBJECT: 1,
    INIT: 2,
    QUERY: 3,
    QUERY_RESULT: 4,
    HIGHLIGHT: 5,
    SELECT: 6,
    SELECT_RESULT: 7,
    REFRESH: 8,
    UPDATE_PROPERTY: 9,
    UPDATE_ATTRIBUTE: 10,
    PANEL_OPENED: 11,
    INSPECT: 12,
    CALL_FUNCTION: 13,
    TRIGGER_EVENT: 14
};

/**
 * This util class is used by the elements of the DevTools
 * to ease in communication with the content script
 * */

/**
 * @param {any} message
 */
async function postMessage(message) {
    document.dispatchEvent(new CustomEvent('__WC_DEV_TOOLS_POST_MESSAGE', { detail: message }));
}

/**
 * @param {string} name
 * @param {any} message
 * @param {any} [object]
 */
async function log(name, message, object) {
    if (object) {
        document.dispatchEvent(
            new CustomEvent('__WC_DEV_TOOLS_LOG_OBJECT', {
                detail: {
                    type: MESSAGE_TYPE.LOG_OBJECT,
                    log: `[WebComponentDevTools@${name}]: ${message}`,
                    data: object,
                },
            }),
        );
    } else {
        document.dispatchEvent(
            new CustomEvent('__WC_DEV_TOOLS_LOG', {
                detail: {
                    type: MESSAGE_TYPE.LOG,
                    log: `[WebComponentDevTools@${name}]: ${message}`,
                },
            }),
        );
    }
}

/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const l=i(class extends s$1{constructor(r){if(super(r),r.type!==t$1.PROPERTY&&r.type!==t$1.ATTRIBUTE&&r.type!==t$1.BOOLEAN_ATTRIBUTE)throw Error("The `live` directive is not allowed on child or event bindings");if(!d(r))throw Error("`live` bindings can only contain a single expression")}render(r){return r}update(i,[t]){if(t===w||t===A)return t;const o=i.element,l=i.name;if(i.type===t$1.PROPERTY){if(t===o[l])return w}else if(i.type===t$1.BOOLEAN_ATTRIBUTE){if(!!t===o.hasAttribute(l))return w}else if(i.type===t$1.ATTRIBUTE&&o.getAttribute(l)===t+"")return w;return f(i),t}});

class DevtoolsTextInput extends h {
    static get properties() {
        return {
            placeholder: { type: String },
            value: { type: String, reflect: true },
            type: { type: String },
            label: { type: String },
            propertyPath: { type: Array },
            property: { type: Object },
        };
    }

    constructor() {
        super();

        this.placeholder = '';
        this.value = '';
        this.property = null;
        this.label = '';
        this.type = 'text';
        this.propertyPath = [];
    }

    _triggerInput(e) {
        e.stopPropagation();
        const value = e.target.value;

        this.dispatchEvent(
            new CustomEvent('devtools-input', {
                detail: { value, property: this.property, propertyPath: this.propertyPath },
                bubbles: true,
                composed: true,
            }),
        );
    }

    getValue() {
        return this.shadowRoot.querySelector('input').value;
    }

    render() {
        return T`${this.label.length > 0 ? T`<label>${this.label}:</label>` : ''}
            <input
                @input=${e => this._triggerInput(e)}
                type="${this.type}"
                placeholder=${this.placeholder}
                .value=${l(this.value)}
            />
            ${this.property?.inheritedFrom
                ? T`<devtools-inheritance-indicator
                      parentClass=${this.property.inheritedFrom.name}
                  ></devtools-inheritance-indicator>`
                : ''} `;
    }

    static get styles() {
        return i$3`
            :host {
                --font-size: 0.8rem;
                display: flex;
                justify-content: flex-start;
                align-items: center;
            }

            input {
                color: var(--button-color);
                height: 100%;
                width: 100%;
                font-size: var(--font-size);
                border-radius: 4px;
                transition: 100ms ease-in-out;
                border: 1px solid #eeeeee;
                outline: none;
            }

            input:focus {
                border: 1px solid var(--highlight);
                background: #d8e9ef;
            }

            label {
                font-size: 0.8rem;
                padding: 3px 1rem 3px 3px;
                color: var(--secondary);
                font-weight: 400;
                white-space: nowrap;
            }

            :host([nolabel]) input {
                flex-basis: 100%;
            }
            :host([nolabel]) label {
                flex-basis: 0;
            }
        `;
    }
}

if (!customElements.get('devtools-text-input')) {
    customElements.define('devtools-text-input', DevtoolsTextInput);
}

class DevtoolsCheckbox extends h {
    static get properties() {
        return {
            checked: { type: Boolean, reflect: true },
            label: { type: String },
            propertyPath: { type: Array },
            property: { type: Object },
        };
    }

    constructor() {
        super();

        this.checked = false;
        this.label = '';
        this.property = null;
        this.propertyPath = [];
    }

    updated(_changed) {
        // The input doesn't seem to update checked status by default
        if (_changed.has('checked')) {
            this.shadowRoot.querySelector('input').checked = this.checked;
        }
    }

    _triggerInput(e) {
        e.stopPropagation();
        const value = e.target.checked;

        this.dispatchEvent(
            new CustomEvent('devtools-input', {
                detail: { value, property: this.property, propertyPath: this.propertyPath },
                bubbles: true,
                composed: true,
            }),
        );
    }

    render() {
        return T`<label>${this.label}</label>
            <span><input @input=${e => this._triggerInput(e)} type="checkbox" ?checked=${l(this.checked)} /></span>
            ${this.property.inheritedFrom
                ? T`<devtools-inheritance-indicator
                      parentClass=${this.property.inheritedFrom.name}
                  ></devtools-inheritance-indicator>`
                : ''} `;
    }

    static get styles() {
        return i$3`
            :host {
                display: flex;
                justify-content: flex-start;
                align-items: center;
            }

            input {
                color: var(--button-color);
                height: 0.8rem;
                width: 0.8rem;
                border-radius: 4px;
                transition: 100ms ease-in-out;
                border: 3px solid #eeeeee;
                outline: none;
            }

            input:focus {
                border: 1px solid cornflowerblue;
            }

            label {
                font-size: 0.8rem;
                padding: 3px 1rem 3px 3px;
                color: var(--secondary);
                font-weight: 400;
                white-space: nowrap;
            }

            :host([nolabel]) input {
                flex-basis: 100%;
            }
            :host([nolabel]) label {
                flex-basis: 0;
            }
        `;
    }
}

if (!customElements.get('devtools-checkbox')) {
    customElements.define('devtools-checkbox', DevtoolsCheckbox);
}

const REFRESH_ICON = T`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M9 12l-4.463 4.969-4.537-4.969h3c0-4.97 4.03-9 9-9 2.395 0 4.565.942 6.179 2.468l-2.004 2.231c-1.081-1.05-2.553-1.699-4.175-1.699-3.309 0-6 2.691-6 6h3zm10.463-4.969l-4.463 4.969h3c0 3.309-2.691 6-6 6-1.623 0-3.094-.65-4.175-1.699l-2.004 2.231c1.613 1.526 3.784 2.468 6.179 2.468 4.97 0 9-4.03 9-9h3l-4.537-4.969z"/></svg>`;
const ARROW_UP = T`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.677 18.52c.914 1.523-.183 3.472-1.967 3.472h-19.414c-1.784 0-2.881-1.949-1.967-3.472l9.709-16.18c.891-1.483 3.041-1.48 3.93 0l9.709 16.18z"/></svg>`;
const INHERITANCE = T`
<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="200.000000pt" height="200.000000pt" viewBox="0 0 200.000000 200.000000"
 preserveAspectRatio="xMidYMid meet">
<g transform="translate(0.000000,200.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M937 1786 c-65 -18 -117 -61 -149 -126 -69 -134 1 -293 149 -336 193
-56 365 148 279 331 -49 107 -166 162 -279 131z"/>
<path d="M629 1262 c-25 -31 -60 -78 -77 -103 -28 -42 -113 -204 -124 -239 -3
-8 -9 8 -12 35 -16 110 -22 130 -39 133 -21 4 -22 -11 -2 -154 18 -126 20
-134 37 -134 18 0 223 159 223 173 0 28 -37 14 -105 -39 -61 -48 -71 -53 -65
-33 17 57 114 226 177 309 37 50 68 95 68 100 0 27 -40 4 -81 -48z"/>
<path d="M1290 1310 c0 -5 31 -50 68 -100 63 -83 160 -252 177 -309 6 -21 -4
-16 -66 32 -70 55 -109 71 -109 44 0 -18 217 -180 233 -174 15 6 56 271 44
283 -16 16 -35 -8 -41 -53 -4 -26 -9 -65 -12 -85 l-6 -38 -49 101 c-53 108
-86 161 -158 251 -41 52 -81 75 -81 48z"/>
<path d="M980 1033 l-1 -138 -32 53 c-31 51 -50 64 -60 39 -7 -18 95 -187 113
-187 18 0 120 169 113 187 -10 25 -29 12 -60 -39 l-32 -53 -1 138 c0 130 -1
137 -20 137 -19 0 -20 -7 -20 -137z"/>
<path d="M277 674 c-31 -9 -65 -31 -92 -58 -115 -116 -90 -299 54 -379 120
-68 274 -17 332 108 23 50 25 142 3 193 -46 112 -180 173 -297 136z"/>
<path d="M920 670 c-137 -46 -198 -201 -132 -331 68 -135 236 -175 355 -86
156 118 112 366 -75 422 -65 19 -80 19 -148 -5z"/>
<path d="M1595 681 c-72 -18 -142 -77 -169 -143 -22 -51 -20 -143 3 -193 58
-125 212 -176 332 -108 66 37 105 90 121 163 34 167 -122 321 -287 281z"/>
</g>
</svg>

`;

class DevToolsInheritanceIndicator extends h {

    static get properties() {
        return {
            parentClass: { type: String, reflect: true },
            hovered: { type: Boolean, reflect: true },
            extends: { type: Boolean, reflect: true },
            dir: { type: String, reflect: true }
        }
    }

    constructor() {
        super();
        this.parentClass = "";
        this.hovered = false;
        this.extends = false;
        this.dir = "up";
    }

    firstUpdated() {
        this.addEventListener("mouseenter", () => this.hovered = true);
        this.addEventListener("mouseleave", () => this.hovered = false);
    }

    render() {
        return T`${INHERITANCE}

            <span class="bubble">
                ${this.extends ? 'Extends' : 'Inherited from'} ${this.parentClass}
            </span>
        `;
    }

    static get styles() {
        return i$3`
            :host {
                display: flex;
                width: 16px;
                height: 16px;
                position: relative;
                margin-left: auto;
            }

            svg {
                width: inherit;
                height: inherit;
            }

            .bubble {
                opacity: 0;
                position: absolute;
                top: 0;
                right: 10px;
                padding: 0.2rem;
                border-radius: 2px;
                background: var(--paragraph-color);
                color: var(--background-color);
                white-space: nowrap;
                width: fit-content;
                transition: 300ms ease-in-out;
                pointer-events: none;
            }

            :host([hovered]) .bubble {
                opacity: 1;
            }

            :host([hovered][dir='up']) .bubble {
                top: -20px;
            }

            :host([hovered][dir='down']) .bubble {
                top: 20px;
            }
        `;
    }
}

if (!customElements.get('devtools-inheritance-indicator')) {
    customElements.define('devtools-inheritance-indicator', DevToolsInheritanceIndicator);
}

class DevToolsEventItem extends h {
    static get properties() {
        return {
            name: { type: String, reflect: true },
            label: { type: String },
            triggered: { type: Boolean, reflect: true },
            event: { type: Object },
        };
    }

    constructor() {
        super();

        this.name = '';
        this.label = '';
        this.triggered = false;
        this.event = null;
    }

    trigger() {
        this.triggered = true;
        setTimeout(() => {
            this.triggered = false;
        }, 50);
    }

    render() {
        return T`${this.label.length > 0 ? T`<label>${this.label}:</label>` : ''}
        ${this.event.inheritedFrom ? T`<devtools-inheritance-indicator parentClass=${this.event.inheritedFrom.name}></devtools-inheritance-indicator>` : ''} `;
    }

    static get styles() {
        return i$3`
            :host {
                --font-size: 0.8rem;
                display: flex;
                justify-content: flex-start;
                align-items: center;
            }

            label {
                font-size: 0.8rem;
                padding: 3px;
                color: var(--secondary);
                font-weight: 400;
                white-space: nowrap;

                background: transparent;
                transition: 1000ms ease-in-out;
            }

            :host([triggered]) label {
                transition: 0ms ease-in-out;
                background: var(--highlight);
                color: var(--background-color);
            }
        `;
    }
}

if (!customElements.get('devtools-event-item')) {
    customElements.define('devtools-event-item', DevToolsEventItem);
}

class DevToolsActionButton extends h {
    static get properties() {
        return {
            label: { type: String },
            primary: { type: Boolean, reflect: true },
            secondary: { type: Boolean, reflect: true },
        };
    }

    constructor() {
        super();
        this.label = '';
        this.primary = false;
        this.secondary = false;
    }

    render() {
        return T`<button>${this.label}</button>`;
    }

    static get styles() {
        return i$3`
            button {
                --button-theme: var(--highlight);

                font-size: calc(var(--font-size) * 0.9);
                background: transparent;
                cursor: pointer;
                border: 1px solid var(--button-theme);
                height: fit-content;
            }

            :host {
                width: fit-content;
                display: inline;
            }

            :host([primary]) button {
                --button-theme: var(--highlight);
                color: var(--button-theme);
            }
            :host([secondary]) button {
                --button-theme: var(--secondary);
                color: var(--button-theme);
            }
        `;
    }
}

if (!customElements.get('devtools-action-button')) {
    customElements.define('devtools-action-button', DevToolsActionButton);
}

class DevToolsMethodItem extends h {
    static get properties() {
        return {
            method: { type: Object },
            selectedElement: { type: Object },
        };
    }

    constructor() {
        super();

        this.method = null;
        this.selectedElement = null;
    }

    openParams() {
        this.shadowRoot.querySelector('details').setAttribute('open', '');
    }

    callMethod() {
        postMessage({
            type: MESSAGE_TYPE.CALL_FUNCTION,
            targetIndex: this.selectedElement.indexInDevTools,
            method: this.method,
            parameters: [],
        });
    }

    callMethodWithParams() {
        const params = Array.from(this.shadowRoot.querySelectorAll('devtools-text-input')).map(input =>
            /** @type DevtoolsTextInput */(input).getValue(),
        );

        postMessage({
            type: MESSAGE_TYPE.CALL_FUNCTION,
            targetIndex: this.selectedElement.indexInDevTools,
            method: this.method,
            parameters: params,
        });
    }

    _hasParams() {
        return this.method.parameters && this.method.parameters.length > 0;
    }

    render() {
        if (!this.method.name) return '';
        return T`
            ${this._hasParams()
                ? T`
                      <details>
                          <summary>
                              <span>
                                  <label>${this.method?.name}:</label
                                  ><devtools-action-button
                                      secondary
                                      label="Set Params"
                                      @click=${this.openParams}
                                  ></devtools-action-button>
                              </span>
                          </summary>
                          <div class="param-list">
                              ${this.method.parameters.map(
                    param => T`
                                      <devtools-text-input
                                          type="text"
                                          label=${param.name}
                                          .value=${param?.default ?? ''}
                                      ></devtools-text-input>
                                  `,
                )}
                          </div>
                          <devtools-action-button
                              class="param-function-caller"
                              primary
                              label="Call Function"
                              @click=${this.callMethodWithParams}
                          ></devtools-action-button>
                      </details>
                  `
                : T`
                      <label>${this.method?.name}:</label
                      ><devtools-action-button
                          primary
                          label="Call Function"
                          @click=${this.callMethod}
                      ></devtools-action-button>
                  `}
            ${this.method.inheritedFrom
                ? T`<devtools-inheritance-indicator
                      parentClass=${this.method.inheritedFrom.name}
                  ></devtools-inheritance-indicator>`
                : ''}
        `;
    }

    static get styles() {
        return i$3`
            :host {
                --font-size: 0.8rem;
                display: flex;
                justify-content: flex-start;
                align-items: center;
            }

            summary {
                margin-left: -0.85rem;
                width: 100%;
                cursor: pointer;
                user-select: none;
            }

            summary > span {
                display: inline;
                width: 100%;
                pointer-events: none;
            }

            details {
                display: flex;
                width: 100%;
            }

            details[open] {
                padding-bottom: 1rem;
            }

            .param-function-caller {
                margin: 0 0 0 1rem;
            }

            label {
                font-size: 0.8rem;
                padding: 3px 1rem 3px 3px;
                color: var(--secondary);
                font-weight: 400;
                white-space: nowrap;
            }

            .param-list {
                display: flex;
                flex-direction: column;
                padding: 0 0 0 1rem;
            }
        `;
    }
}

if (!customElements.get('devtools-method-item')) {
    customElements.define('devtools-method-item', DevToolsMethodItem);
}

/**
 * @typedef InputOptions
 * @property {any} property
 * @property {String} propertyName
 * @property {any} value
 * @property {Function} [inputCallback]
 * @property {Array<String>} [propertyPath]
 * @param {any} options
 */

/**
 * @param {InputOptions} options
 * */
function renderObjectProperty(options) {
    return T`
        <li>
            <devtools-object-input
                .property=${options.property}
                .propName=${options.propertyName}
                .object=${options.value}
                .propertyPath=${options.propertyPath ?? []}
                @devtools-input=${e => options.inputCallback && options.inputCallback(e.detail)}
            ></devtools-object-input>
        </li>
    `;
}

/**
 * @param {InputOptions} options
 */
function renderNumberProperty(options) {
    return T`
        <li>
            <devtools-text-input
                type="number"
                label=${options.propertyName}
                .property=${options.property}
                .value=${options.value ?? ''}
                .propertyPath=${options.propertyPath ?? []}
                @devtools-input=${e => options.inputCallback && options.inputCallback(e.detail)}
            ></devtools-text-input>
        </li>
    `;
}

/**
 * @param {InputOptions} options
 */
function renderStringProperty(options) {
    return T`
        <li>
            <devtools-text-input
                label=${options.propertyName}
                .property=${options.property}
                .value=${options.value ?? ''}
                .propertyPath=${options.propertyPath ?? []}
                @devtools-input=${e => options.inputCallback && options.inputCallback(e.detail)}
            ></devtools-text-input>
        </li>
    `;
}

/**
 * @param {InputOptions} options
 */
function renderBooleanProperty(options) {
    return T`
        <li>
            <devtools-checkbox
                label=${options.propertyName}
                .property=${options.property}
                ?checked=${options.value ?? false}
                .propertyPath=${options.propertyPath ?? []}
                @devtools-input=${e => options.inputCallback && options.inputCallback(e.detail)}
            ></devtools-checkbox>
        </li>
    `;
}

class DevtoolsObjectInput extends h {
    static get properties() {
        return {
            object: { type: Object },
            property: { type: Object },
            propName: { type: String },
            objectPropertyTemplate: { type: Object },
            propertyPath: { type: Array },
            hasBeenOpened: { type: Boolean }
        };
    }

    constructor() {
        super();
        this.object = {};
        this.property = {};
        this.propName = '';
        this.objectPropertyTemplate = T``;
        this.propertyPath = [];
        this.hasBeenOpened = false;
    }

    updated(_changedProperties) {
        if (this.hasBeenOpened && _changedProperties.has("object")) {
            this.objectPropertyTemplate = this.getObjectProperties();
        }
    }

    _onToggle(e) {
        if (e.target.open) {
            this.objectPropertyTemplate = this.getObjectProperties();
            this.hasBeenOpened = true;
        }
    }

    _getObjectPreview() {
        let objectPreview = JSON.stringify(this.object);
        if (objectPreview.length > 40) objectPreview = objectPreview.substring(0, 40) + '...';
        return objectPreview;
    }

    render() {
        return T`
            <details @toggle=${this._onToggle}>
                <summary>
                    <span
                        ><label>${this.propName}:</label
                        ><label class="preview">${this._getObjectPreview()}</label></span
                    >
                </summary>
                ${this.objectPropertyTemplate}
            </details>
        `;
    }

    getObjectProperties() {
        if (typeof this.object === 'object' && Object.keys(this.object).length <= 0) {
            return T`<label class="no-length-indicator">${Array.isArray(this.object) ? '[]' : '{}'}</label>`;
        }
        return T` ${Object.keys(this.object).map(key => this.renderProperty({ name: key }))}`;
    }

    renderProperty(prop) {
        let propName = prop.name.startsWith('__') ? prop.name.substring(2) : prop.name;
        propName = propName.substring(0, 1).toUpperCase() + propName.substring(1);
        const value = this.object ? this.object[prop.name] ?? '' : '';
        const type = typeof value ?? 'string';
        prop.type = { text: type };
        switch (type) {
            case 'boolean':
                return renderBooleanProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    propertyPath: [...this.propertyPath, this.property.name],
                });
            case 'number':
                return renderNumberProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    propertyPath: [...this.propertyPath, this.property.name],
                });
            // @ts-ignore
            case 'array':
            case 'object':
                return renderObjectProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    propertyPath: [...this.propertyPath, this.property.name],
                });
            default:
                return renderStringProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    propertyPath: [...this.propertyPath, this.property.name],
                });
        }
    }

    static get styles() {
        return i$3`
            :host {
                --font-size: 0.8rem;
                display: flex;
                justify-content: flex-start;
                align-items: center;
            }

            summary {
                margin-left: -0.85rem;
                width: 100%;
                cursor: pointer;
                user-select: none;
            }
            summary > span {
                display: inline;
                width: 100%;
                box-sizing: border-box;
                pointer-events: none;
            }

            details {
                display: flex;
                width: 100%;
                padding-left: 0.8rem;
            }

            details[open] {
                padding-bottom: 1rem;
            }

            .param-function-caller {
                margin: 0 0 0 1rem;
            }

            label {
                font-size: 0.8rem;
                padding: 0 1rem 0 3px;
                color: var(--secondary);
                font-weight: 400;
                white-space: nowrap;
                vertical-align: middle;
            }

            .preview {
                font-size: 0.65rem;
                color: var(--highlight);
            }

            .no-length-indicator {
                color: var(--highlight);
            }

            .param-list {
                display: flex;
                flex-direction: column;
                padding: 0 0 0 1rem;
            }
        `;
    }
}

if (!customElements.get('devtools-object-input')) {
    customElements.define('devtools-object-input', DevtoolsObjectInput);
}

class CustomElementsInspectorCategory extends h {
    static get properties() {
        return {
            items: { type: Array },
            values: { type: Object },
            title: { type: String },
            selectedElement: { type: Object },
            categoryType: { type: String },
        };
    }

    constructor() {
        super();
        this.title = '';
        this.items = [];
        this.values = {};
        /** @type DevToolsElement */
        this.selectedElement = null;
        this.categoryType = 'attributes';
    }

    firstUpdated() {
        if (this.categoryType === 'events') {
            document.addEventListener(MESSAGE_TYPE.TRIGGER_EVENT.toString(), (/** @type {CustomEvent} */ event) => {
                const eventData = event.detail.eventData;
                const targetEventItem = /** @type DevToolsEventItem */ (
                    this.shadowRoot.querySelector(`devtools-event-item[name='${eventData.event.name}']`)
                );
                if (targetEventItem) {
                    targetEventItem.trigger();
                }
            });
        }
    }

    updateAttributeOrPropertyValue(eventData) {
        const elementType = this.selectedElement.typeInDevTools;

        const eventType =
            this.categoryType === 'attributes' ? MESSAGE_TYPE.UPDATE_ATTRIBUTE : MESSAGE_TYPE.UPDATE_PROPERTY;

        postMessage({
            type: eventType,
            index: this.selectedElement.indexInDevTools,
            value: eventData.value,
            elementType,
            attributeOrProperty: eventData.property,
            propertyPath: eventData.propertyPath,
        });

        postMessage({
            type: MESSAGE_TYPE.SELECT,
            indexInDevTools: this.selectedElement.indexInDevTools,
            name: this.selectedElement.name,
            tagName: this.selectedElement.tagName,
        });
    }

    renderItem(item) {
        switch (this.categoryType) {
            case 'attributes':
            case 'properties':
                return this.renderProperty(item);
            case 'events':
                return this.renderEvent(item);
            case 'methods':
                return this.renderMethod(item);
        }
    }

    renderProperty(prop) {
        let propName = prop.name.startsWith('__') ? prop.name.substring(2) : prop.name;
        propName = propName.substring(0, 1).toUpperCase() + propName.substring(1);
        const value = this.values ? this.values[prop.name] ?? '' : '';
        const type = prop?.type?.text ?? 'string';
        switch (type) {
            case 'boolean':
                return renderBooleanProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    inputCallback: this.updateAttributeOrPropertyValue.bind(this),
                });
            case 'number':
                return renderNumberProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    inputCallback: this.updateAttributeOrPropertyValue.bind(this),
                });
            case 'array':
            case 'object':
                return renderObjectProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    inputCallback: this.updateAttributeOrPropertyValue.bind(this),
                });
            default:
                return renderStringProperty({
                    property: prop,
                    propertyName: propName,
                    value: value,
                    inputCallback: this.updateAttributeOrPropertyValue.bind(this),
                });
        }
    }

    renderEvent(item) {
        return T` <li>
            <devtools-event-item .event=${item} name=${item.name} label=${item.name}></devtools-event-item>
        </li>`;
    }

    renderMethod(item) {
        return T`<li>
            <devtools-method-item .selectedElement=${this.selectedElement} .method=${item}></devtools-method-item>
        </li>`;
    }

    render() {
        return T`
            <details open>
                <summary>${this.title}</summary>
                <ul>
                    ${this.items.map(item => this.renderItem(item))}
                </ul>
            </details>
        `;
    }

    static get styles() {
        return i$3`
            :host {
                display: flex;
                padding: 0.5rem 0 1rem 0.5rem;
                font-size: 0.8rem;
            }

            details {
                width: 100%;
            }

            summary {
                cursor: pointer;
                user-select: none;
            }

            ul,
            li {
                list-style: none;
            }

            li {
                padding: 0 0 0 1rem;
            }

            ul {
                padding: 0;
                margin: 0;
            }
        `;
    }
}

if (!customElements.get('custom-elements-inspector-category')) {
    customElements.define('custom-elements-inspector-category', CustomElementsInspectorCategory);
}

const MESSAGING_CHANNEL$1 = 'CustomElementsInspector';

class CustomElementsInspector extends h {
    static get properties() {
        return {
            selectedElement: { type: Object },
            customElementsList: { type: Object },
            verticalView: { type: Boolean },
        };
    }

    constructor() {
        super();

        this.reload();
        this.customElementsList = null;
        this._initSubChannel();
        this.verticalView = true;

        const mediaQ = window.matchMedia('(max-width: 1000px)');
        mediaQ.addEventListener('change', mediaQresponse => {
            this.verticalView = mediaQresponse.matches;
        });

        this.onResizeMouseMoveListener = this.onResizeMouseMove.bind(this);
    }

    reload() {
        /** @type DevToolsElement */
        this.selectedElement = null;
    }

    _initSubChannel() {
        document.addEventListener(MESSAGE_TYPE.REFRESH.toString(), this.reload.bind(this));
        document.addEventListener(MESSAGE_TYPE.SELECT_RESULT.toString(), (/** @type {CustomEvent} */ event) => {
            const message = event.detail;
            this.selectedElement = message.data;
        });
    }

    firstUpdated() {
        this.customElementsList = document.querySelector('custom-elements-list');
    }

    /**
     * @param {any} element
     */
    setSelectedElement(element) {
        if (this.selectedElement?.indexInDevTools !== element?.index) {
            postMessage({
                type: MESSAGE_TYPE.SELECT,
                indexInDevTools: element.index,
                name: element.name,
                tagName: element.name,
            });
        }
    }

    onResizeMouseMove(e) {
        if (this.verticalView) {
            const newFlexPercentage = (100 - (e.clientY / window.innerHeight) * 95).toFixed(0);
            this.style.setProperty('--inspector-size', newFlexPercentage + '%');
        } else {
            const newFlexPercentage = (100 - (e.clientX / window.innerWidth) * 95).toFixed(0);
            this.style.setProperty('--inspector-size', newFlexPercentage + '%');
        }
    }

    resizeStart() {
        document.addEventListener('mousemove', this.onResizeMouseMoveListener);
        const removeListener = () => {
            document.removeEventListener('mousemove', this.onResizeMouseMoveListener);
            document.removeEventListener('mouseup', removeListener);
            document.removeEventListener('mouseleave', removeListener);
        };
        document.addEventListener('mouseup', removeListener);
        document.addEventListener('mouseleave', removeListener);
    }

    resizeEnd() {
        document.removeEventListener('mousemove', this.onResizeMouseMoveListener);
    }

    render() {
        return T`
            <div class="splitter" @mousedown=${this.resizeStart}><span></span></div>

            <div class="action-area">
                ${this.showHeader()}
                ${this.selectedElement
                ? T`
                          ${this.showProperties()} ${this.showAttributes()} ${this.showEvents()} ${this.showMethods()}
                      `
                : ''}
            </div>
        `;
    }

    showHeader() {
        return T`
            <header>
                <h2>${this.selectedElement?.name ?? ''}</h2>
                ${this.selectedElement?.parentClass
                ? T`
                          <devtools-inheritance-indicator
                              extends
                              dir="down"
                              .parentClass=${this.selectedElement.parentClass.name}
                          ></devtools-inheritance-indicator>
                      `
                : ''}
            </header>
        `;
    }

    showProperties() {
        if (!this.selectedElement.properties || this.selectedElement.properties.length <= 0) return '';
        return T` <div class="properties">
            <custom-elements-inspector-category
                title="Properties"
                .items=${this.selectedElement.properties}
                .values=${this.selectedElement.propertyValues}
                .selectedElement=${this.selectedElement}
                categoryType="properties"
            ></custom-elements-inspector-category>
        </div>`;
    }
    showAttributes() {
        if (!this.selectedElement.attributes || this.selectedElement.attributes.length <= 0) return '';
        return T` <div class="attributes">
            <custom-elements-inspector-category
                title="Attributes"
                .items=${this.selectedElement.attributes}
                .values=${this.selectedElement.attributeValues}
                .selectedElement=${this.selectedElement}
                categoryType="attributes"
            ></custom-elements-inspector-category>
        </div>`;
    }
    showEvents() {
        if (!this.selectedElement.events || this.selectedElement.events.length <= 0) return '';
        return T` <div class="events">
            <custom-elements-inspector-category
                title="Events"
                .items=${this.selectedElement.events}
                .selectedElement=${this.selectedElement}
                categoryType="events"
            ></custom-elements-inspector-category>
        </div>`;
    }
    showMethods() {
        if (!this.selectedElement.methods || this.selectedElement.methods.length <= 0) return '';
        return T` <div class="methods">
            <custom-elements-inspector-category
                title="Methods"
                .items=${this.selectedElement.methods}
                .selectedElement=${this.selectedElement}
                categoryType="methods"
            ></custom-elements-inspector-category>
        </div>`;
    }

    static get styles() {
        return i$3`
            :host {
                --inspector-size: 40%;

                flex-basis: var(--inspector-size);
                display: flex;
                height: 100%;

                height: 100%;
                max-height: 100%;
                overflow-y: auto;
                box-sizing: border-box;
            }

            .action-area {
                width: 95%;
                display: flex;
                flex-direction: column;
                padding-bottom: 5rem;
                margin-top: -0.5rem;
            }

            header {
                display: flex;
                align-items: center;
                border-bottom: 2px solid #eeeeee;
                justify-content: space-between;
                box-sizing: border-box;
                padding: 0.5rem 1rem;
            }

            header h2 {
                font-size: 1rem;
                color: var(--headline-color);
                margin: 0.5rem 0 0 0;
            }

            .splitter {
                position: sticky;
                background: var(--background-color);
                top: 0;
                width: 4px;
                height: 100%;
                padding: 0 1rem;
                display: flex;
                cursor: col-resize;
            }

            .splitter > span {
                width: inherit;
                height: 100%;
                background: var(--highlight);
                position: relative;
            }

            .splitter > span:before,
            .splitter > span:after {
                content: '';
                position: absolute;
                background: var(--highlight);
                width: 2px;
                height: 1rem;
                top: 0;
                bottom: 0;
                margin: auto;
            }

            .splitter > span:after {
                right: 0.3rem;
            }
            .splitter > span:before {
                left: 0.3rem;
            }

            @media only screen and (max-width: 1000px) {
                :host {
                    --inspector-size: 60%;
                    flex-direction: column;
                    flex-basis: var(--inspector-size);
                }

                header h2 {
                    margin: 0;
                }

                .splitter {
                    width: 100%;
                    height: 4px;
                    padding: 1rem 0;
                    cursor: row-resize;
                }

                .splitter > span {
                    width: 100%;
                    height: inherit;
                }
                .splitter > span:after,
                .splitter > span:before {
                    width: 1rem;
                    height: 2px;
                    left: 0;
                    right: 0;
                }

                .splitter > span:after {
                    bottom: 0.3rem;
                }
                .splitter > span:before {
                    top: 0.3rem;
                }
            }
        `;
    }

    /**
     * @param {any} message
     */
    _log(message) {
        log(MESSAGING_CHANNEL$1, message);
    }

    /**
     * @param {any} message
     * @param {any} object
     */
    _logObject(message, object) {
        log(MESSAGING_CHANNEL$1, message, object);
    }
}

if (!customElements.get('custom-elements-inspector')) {
    customElements.define('custom-elements-inspector', CustomElementsInspector);
}

class CustomElementsListItem extends h {
    static get properties() {
        return {
            element: { type: Object },
            selected: { type: Boolean, reflect: true },
            hasChildren: { type: Boolean, reflect: true },
            relativeDepth: { type: Number, reflect: true },
        };
    }

    constructor() {
        super();
        this.element = null;
        this.selected = false;
        this.hasChildren = false;
        this.tabIndex = 0;
        this.relativeDepth = 0;
    }

    firstUpdated() {
        this.addEventListener('mouseenter', this._spotlight);
        this.addEventListener('mouseleave', this._spotlightOff);
        this.addEventListener('click', this._select);

        this.addEventListener('keydown', this._handleKeyboard);
        this.addEventListener('focus', this._spotlight);
        this.addEventListener('blur', this._spotlightOff);
    }

    /**
     * @param {KeyboardEvent} e
     */
    _handleKeyboard(e) {
        switch (e.key) {
            case 'ArrowUp':
                e.preventDefault();
                this.dispatchEvent(new CustomEvent('list-item-focus-previous'));
                break;
            case 'ArrowDown':
                e.preventDefault();
                this.dispatchEvent(new CustomEvent('list-item-focus-next'));
                break;
            case 'Enter':
                e.preventDefault();
                this._select();
                break;
            case 'ArrowLeft': // TODO
            case 'ArrowRight':
                e.preventDefault();
                this._toggleChildren();
                break;
        }
    }

    _spotlight() {
        postMessage({
            type: MESSAGE_TYPE.HIGHLIGHT,
            index: this.element.index,
        });
    }

    _spotlightOff() {
        postMessage({ type: MESSAGE_TYPE.HIGHLIGHT, index: -1 });
    }

    _select() {
        const selectEvent = new CustomEvent('list-item-selected', {
            detail: this.element,
        });
        this.dispatchEvent(selectEvent);
    }

    _toggleChildren() {
        const toggleEvent = new CustomEvent('list-item-children-toggle', {
            detail: this.element,
        });
        this.dispatchEvent(toggleEvent);
    }

    render() {
        return T`
            <li style="padding-left: ${this.relativeDepth}rem">
                ${this.hasChildren
                ? T` <span class="child-toggler" @click=${this._toggleChildren}>${ARROW_UP}</span> `
                : ''}
                <span>${this.element.name}</span>
            </li>
        `;
    }

    static get styles() {
        return i$3`
            :host {
                display: list-item;
                padding: 0.1rem 0.1rem 0.1rem 0.75rem;
                list-style: none;
                transition: 100ms ease-in-out;
                cursor: pointer;
                color: var(--highlight);
                user-select: none;
            }

            :host([haschildren]) {
                padding-left: 0.1rem;
            }

            :host([hidden]) {
                display: none;
            }

            .child-toggler svg {
                transition: 100ms ease-in-out;
                transform: rotate(180deg);
                height: 0.4rem;
                width: 0.4rem;
            }

            :host([children-hidden]) .child-toggler svg {
                transform: rotate(90deg);
            }

            :host(:hover),
            :host(:focus) {
                background: #d8e9ef;
            }

            :host([selected]) {

                background: #b7e1ef;
            }
        `;
    }
}

if (!customElements.get('custom-elements-list-item')) {
    customElements.define('custom-elements-list-item', CustomElementsListItem);
}

const MESSAGING_CHANNEL = 'CustomElementList';

class CustomElementList extends h {
    static get properties() {
        return {
            customElementList: { type: Array },
            shownCustomElements: { type: Array },
            currentFilter: { type: Object },
            customElementMap: { type: Object },
            selectedElement: { type: Object },
            customElementsInspector: { type: Object },
        };
    }

    constructor() {
        super();
        /** @type {CustomElementsInspector} */
        this.customElementsInspector = null;
        this.reload();
        this._initSubChannel();
    }

    reload() {
        /** @type {Array<any>} */
        this.customElementList = [];
        this.customElementMap = {};
        this.selectedElement = null;
        this.shownCustomElements = [];
        this.currentFilter = {};
    }

    _initSubChannel() {
        document.addEventListener(MESSAGE_TYPE.REFRESH.toString(), this.reload.bind(this));
        document.addEventListener(MESSAGE_TYPE.INIT.toString(), () => { });
        document.addEventListener(MESSAGE_TYPE.QUERY_RESULT.toString(), (/** @type {CustomEvent} */ event) => {
            const message = event.detail;

            if (message.data) {
                this.customElementMap = message.data.elementsMap;
                this.customElementList = message.data.elementsArray;
                this._updateCurrentShownCustomElements();
            }
        });
        document.addEventListener(MESSAGE_TYPE.SELECT_RESULT.toString(), (/** @type {CustomEvent} */ event) => {
            const message = event.detail;
            this.selectedElement = message.data;
            this._focusOnListItemAtIndex(message.data.indexInDevTools);
        });
    }

    _updateCurrentShownCustomElements() {
        this.shownCustomElements = this.customElementList.filter(elem => {
            const nameFilterString = this.currentFilter?.nameFilter;
            if (!nameFilterString) return true;

            const regx = new RegExp(nameFilterString);
            return regx.test(elem.name);
        });
    }

    firstUpdated() {
        this.customElementsInspector = document.querySelector('custom-elements-inspector');
    }

    /**
     * @param {any} message
     */
    _log(message) {
        log(MESSAGING_CHANNEL, message);
    }

    /**
     * @param {any} message
     * @param {any} object
     */
    _logObject(message, object) {
        log(MESSAGING_CHANNEL, message, object);
    }

    _query() {
        postMessage({ type: MESSAGE_TYPE.QUERY });
    }

    /**
     * @param {CustomEvent} event
     */
    _onElementSelect(event) {
        const elem = event.detail;
        this.customElementsInspector.setSelectedElement(elem);
    }

    /**
     * @param {number} index
     */
    _getElementInTreeByIndex(index) {
        const elems = this.shadowRoot.querySelectorAll('custom-elements-list-item');
        return elems[index];
    }

    /**
     * @param {any} elem
     */
    _getChildElementsInTree(elem) {
        const childElementRange = this._getChildElementRange(elem);
        const listElements = Array.from(this.shadowRoot.querySelectorAll('custom-elements-list-item'));
        const children = listElements.slice(childElementRange[0], childElementRange[1]);

        return children;
    }

    /**
     * @param {{ index: number; __WC_DEV_TOOLS_ELEMENT_DEPTH: number; }} elem
     */
    _getChildElementRange(elem) {
        const elementsBelow = this.customElementList.slice(elem.index + 1);

        let childCount = 0;
        while (elementsBelow.length > 0) {
            const el = elementsBelow.shift();
            if (el.__WC_DEV_TOOLS_ELEMENT_DEPTH <= elem.__WC_DEV_TOOLS_ELEMENT_DEPTH) break;
            childCount++;
        }

        return [elem.index + 1, elem.index + childCount + 1];
    }

    /**
     * @param {any} elem
     */
    _hasChildren(elem) {
        const childElementRange = this._getChildElementRange(elem);
        return childElementRange[0] < childElementRange[1];
    }

    /**
     * @param {CustomEvent} event
     * */
    _toggleChildren(event) {
        const elem = event.detail;
        const children = this._getChildElementsInTree(elem);
        children.forEach(child => child.toggleAttribute('hidden'));
        this._getElementInTreeByIndex(elem.index).toggleAttribute('children-hidden');
    }

    /**
     * @param {string} moveDirection
     */
    _moveFocus(moveDirection) {
        /** @type { HTMLElement } */
        let target = this._getMovementTarget(moveDirection);
        if (target) {
            target.focus();
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    _getMovementTarget(moveDirection) {
        /** @type { HTMLElement } */
        let target;
        if (moveDirection === 'down') {
            target = /** @type { HTMLElement } */(this.shadowRoot.activeElement.nextElementSibling);
            while (!target.offsetParent) {
                target = /** @type { HTMLElement } */(target.nextElementSibling);
            }
        } else {
            target = /** @type { HTMLElement } */(this.shadowRoot.activeElement.previousElementSibling);
            while (!target.offsetParent) {
                target = /** @type { HTMLElement } */(target.previousElementSibling);
            }
        }
        return target;
    }

    _focusOnListItemAtIndex(index) {
        const target = /** @type {HTMLElement} */ (
            Array.from(this.shadowRoot.querySelectorAll('custom-elements-list-item'))[index]
        );
        if (target) {
            //target.focus(); // Can cause High levels of Jank if applied with the spotlight on focus action
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    _onWordFilterInput(e) {
        const val = e.detail.value;
        this.currentFilter.nameFilter = val.toLowerCase();
        this._updateCurrentShownCustomElements();
    }

    render() {
        return T`
            <header>
                <devtools-text-input
                    nolabel
                    @devtools-input=${this._onWordFilterInput}
                    placeholder="Filter by name"
                ></devtools-text-input>

                <button @click=${this._query} class="refresh-button">${REFRESH_ICON}</button>
            </header>
            <ul>
                ${this.renderElements()}
            </ul>
        `;
    }

    renderElements() {
        return T`
            ${c(
            this.shownCustomElements,
            elem => elem.name,
            elem => T`
                    <custom-elements-list-item
                        .element=${elem}
                        .relativeDepth=${elem.__WC_DEV_TOOLS_ELEMENT_DEPTH}
                        ?selected=${this.selectedElement?.indexInDevTools === elem.index}
                        ?hasChildren=${this._hasChildren(elem)}
                        @list-item-selected=${this._onElementSelect}
                        @list-item-children-toggle=${this._toggleChildren}
                        @list-item-focus-next=${() => this._moveFocus('down')}
                        @list-item-focus-previous=${() => this._moveFocus('up')}
                    >
                    </custom-elements-list-item>
                `,
        )}
        `;
    }

    static get styles() {
        return i$3`
            :host {
                flex: 1 20 auto;
                position: relative;
                max-height: 100%;
                min-height: 1%;
            }

            ul {
                padding: 0 1rem;
                max-height: calc(100% - 78px);
                overflow-y: auto;
                box-sizing: border-box;
            }

            header {
                display: flex;
                align-items: center;
                border-bottom: 2px solid #eeeeee;
                height: 56px;
                justify-content: space-between;
                box-sizing: border-box;
                background: var(--background-color);
                padding: 0 1rem;
            }

            .refresh-button {
                background: none;
                border: none;
                cursor: pointer;
                transition: 400ms ease-in-out;
                transform: rotate(0);
                margin-right: 1rem;
            }

            .refresh-button:hover {
                transform: rotate(-150deg);
            }

            devtools-text-input {
                --font-size: 1.3rem;
            }
        `;
    }
}

customElements.define('custom-elements-list', CustomElementList);

const CONNECTION_CHANNELS = {
    DEVTOOLS_PANEL_TO_CONTENT: "Lit DevTools - Panel to Content",
    DEVTOOLS_INITIALIZER: "Lit DevTools - Initializer",
    DEVTOOLS_BACKGROUND_CONTENT: "Lit DevTools - Background to Content",
    DEVTOOLS_CONTEXT_MENU_TO_BACKGROUND: "Lit DevTools - Context Menus to Background"
};

/**
 * @typedef NydusOptions
 * @property {Array<NydusConnectionOptions>} connections
 * @property {NydusCallback} [onReady]
 * @property {NydusConnectCallback} [onConnect]
 * @property{boolean} [isBackground]
 * */

/**
 *   @callback NydusConnectCallback
 *   @param {Nydus} nydus
 *   @param {chrome.runtime.Port} connection
 * */

/**
 * @typedef NydusConnectionPool
 * @type Object.<string, NydusConnection>
 * */

/**
 * @typedef NydusConnectionPoolTabMap
 * @type Object.<number, NydusConnectionPool>
 * */

/**
 * @typedef NydusConnection
 * @property {string | number} id
 * @property {number} [tabId]
 * @property {chrome.runtime.Port} [connection]
 * @property {NYDUS_CONNECTION_ROLE} role
 * @property {boolean} ready
 * */

/**
 * @typedef NydusConnectionOptions
 * @property {string | number} id
 * @property {OnMessageCallback} [onMessage]
 * @property {boolean} host
 * @property {boolean} [isBackground]
 * */

/**
 * @readonly
 * @enum {number} NydusConnectionRole
 * */
const NYDUS_CONNECTION_ROLE = {
    HOST: 0,
    CLIENT: 1,
};

const NYDUS_CONNECTION_HANDSHAKE = 'NYDUS_CONNECTION_HANDSHAKE';
const NYDUS_TAB_PING = 'NYDUS_TAB_PING';

/**
 * @param {NydusOptions} nydusOptions
 *
 * @returns {Nydus} nydus;
 */
function buildNydus(nydusOptions) {
    const nydus = new Nydus(nydusOptions);

    return nydus;
}

/**
 * @callback NydusCallback
 * @param {Nydus} nydus
 * */

/**
 * @callback OnMessageCallback
 * @param {any} message
 * */

/**
 *  A Routing / Orchestration tool for concurrent connections between dev tools closures
 * */
class Nydus {
    /**
     * @param {NydusOptions} nydusOptions
     */
    constructor(nydusOptions) {
        /** @type {Array<NydusConnectionOptions>} */
        this.connectionOptions = nydusOptions.connections;
        /** @type {NydusCallback} */
        this.onReady = nydusOptions.onReady;
        /** @type {NydusConnectCallback} */
        this.onConnect = nydusOptions.onConnect;

        /** @type { NydusConnectionPoolTabMap } */
        this.connections = {};
        /** @type {boolean} */
        this.ready = false;

        this._whenReadyResolver = null;
        this.whenReady = new Promise(resolve => {
            this._whenReadyResolver = resolve;
        });

        this._needsToSpecifyTab = this._canAccessTabs();
        this.nydusTab = null;

        this._createAllConnections();
    }

    async _createAllConnections() {
        await this._determineTabIds();
        this.connectionOptions.forEach(connectionOpts => {
            this.addConnection(
                connectionOpts.id,
                !connectionOpts.host,
                connectionOpts.onMessage,
                connectionOpts.isBackground,
            );
        });
    }

    /**
     *
     * Communication is important to keep tab-specific so that if the user has
     * 2 instances of WC DevTools open, they don't mix up each other.
     *
     * If the view has access to chrome.tabs, it means they are a background
     * task, and can easily query the tab. These ones will we make "Hosts" to
     * provide the tab info to others.
     *
     * Then others who can't access chrome.tabs, will send a one time message,
     * hoping for an answer to this question.
     *
     * This function is promisified so that we can make sure we have caught a tab ID before
     * proceeding with other actions.
     * */
    _determineTabIds() {
        return new Promise(resolve => {
            if (chrome.tabs) {
                chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
                    if (request.type === NYDUS_TAB_PING) {
                        sendResponse({ type: NYDUS_TAB_PING, tabId: sender.tab?.id });
                    }
                });
                chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
                    this.nydusTab = tabs[0]?.id ?? chrome.devtools.inspectedWindow.tabId;
                    resolve();
                });
            } else {
                chrome.runtime.sendMessage({ type: NYDUS_TAB_PING }, response => {
                    this.nydusTab = response.tabId;
                    resolve(response.tabId);
                });
            }
        });
    }

    /**
     * Add a connection to the Nydus with a given ID
     *
     * @param {number | string} connectionId
     * @param {boolean} isClient
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    addConnection(connectionId, isClient, onMessage, isBackground = false) {
        if (this.connections[connectionId]) return; // No duplicates

        const nydusConnection = {
            id: connectionId,
            role: isClient ? NYDUS_CONNECTION_ROLE.CLIENT : NYDUS_CONNECTION_ROLE.HOST,
            ready: false,
        };

        this._doConnectionHandshake(nydusConnection, onMessage, isBackground);
    }

    /**
     * Add a connection to Nydus as a host connector.
     *
     * Being a host means that you createa connection, and expect
     * a client to be listening for it, and approve it with a handshake.
     *
     * @param {string | number} connectionId
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    addHostConnection(connectionId, onMessage, isBackground = false) {
        this.addConnection(connectionId, false, onMessage, isBackground);
    }

    /**
     * Add a connection to Nydus as a client connector.
     *
     * Being a client means that you are listening for a Host
     * to create a connection, and then after a handshake can communicate
     *
     * @param {string | number} connectionId
     * @param {OnMessageCallback} onMessage
     */
    addClientConnection(connectionId, onMessage) {
        this.addConnection(connectionId, true, onMessage, false);
    }

    /**
     * Messages the desired Nydus Connection is one
     * is found with the name/id provided
     *
     * @param {string | number} recipient
     * @param {any} message
     */
    async message(recipient, message) {
        await this.whenReady;

        const tabId = await this._tryGetCurrentTab();
        let connPool = this.connections[tabId] ?? this.connections[-1];
        if (!connPool) {
            console.warn('[WebComponentDevTools]: Message send missed. Tab connection pool not found.', {
                recipient,
                message,
                tabId,
            });
            return;
        }

        const conn = connPool[recipient]?.connection;
        if (!conn) {
            console.warn('[WebComponentDevTools]: Message send missed. Connection not found.', {
                recipient,
                message,
                tabId,
            });
            return;
        }
        conn.postMessage({ ...message, tabId });
    }

    /**
     * Messages all of the connections in the Nydus Connection Pool
     *
     * @param {any} message
     */
    messageAll(message) {
        Object.values(this.connections).forEach(connPool => {
            connPool.forEach((/** @type {NydusConnection} */ conn) => {
                conn.connection.postMessage(message);
            });
        });
    }

    /**
     * Awaitable timeout
     *
     * @param {number} ms
     */
    _delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    _doConnectionHandshake(nydusConnection, onMessage, isBackground) {
        if (nydusConnection.role === NYDUS_CONNECTION_ROLE.HOST) {
            this._doHostHandshake(nydusConnection, onMessage, isBackground);
        } else {
            this._doClientHandshake(nydusConnection, onMessage, isBackground);
        }
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    async _doClientHandshake(nydusConnection, onMessage, isBackground) {
        // We delay the connector init a bit to avoid race conditions
        // This could maybe be removed later, but needs testing
        await this._delay(100);

        const connection = await this._createConnection(nydusConnection, isBackground);
        nydusConnection.connection = connection;

        connection.onMessage.addListener(
            function finishHandshake(/** @type {any} */ message) {
                this._handleConnectionHandshakeMessage(message, nydusConnection);
                connection.onMessage.removeListener(finishHandshake);
                if (onMessage) {
                    connection.onMessage.addListener(onMessage);
                }
            }.bind(this),
        );
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {boolean} isBackground
     */
    _createConnection(nydusConnection, isBackground) {
        return new Promise(async resolve => {
            let connection;
            let tabId;
            // In devtools context we need to specify which tab to target
            if (this._canAccessTabs() && !isBackground) {
                tabId = await this._tryGetCurrentTab();
                connection = chrome.tabs.connect(tabId, {
                    name: nydusConnection.id.toString(),
                });
            } else {
                tabId = -1;
                connection = chrome.runtime.connect({
                    name: nydusConnection.id.toString(),
                });
            }
            this._addConnectionToPool(tabId, nydusConnection);
            this._addConnectionOnDisconnectListeners(connection, nydusConnection.id.toString(), tabId);
            resolve(connection);
        });
    }

    /**
     * @param {chrome.runtime.Port} connection
     * @param {string | number} connectionId
     * @param {string | number} tabId
     */
    _addConnectionOnDisconnectListeners(connection, connectionId, tabId) {
        connection.onDisconnect.addListener(() => {
            delete this.connections[tabId][connectionId];
        });
    }

    _tryGetCurrentTab() {
        return new Promise(resolve => {
            if (!this._canAccessTabs()) {
                return resolve(this.nydusTab ?? -1);
            }
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
                const tabId = tabs.length < 1 ? chrome.devtools.inspectedWindow.tabId : tabs[0].id;
                resolve(tabId ?? -1);
            });
        });
    }

    /**
     * @param {number} tabId
     * @param {NydusConnection} nydusConnection
     */
    _addConnectionToPool(tabId, nydusConnection) {
        nydusConnection.tabId = tabId;
        if (!this.connections[tabId]) this.connections[tabId] = {};
        this.connections[tabId][nydusConnection.id] = nydusConnection;
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     */
    _doHostHandshake(nydusConnection, onMessage, isBackground) {
        chrome.runtime.onConnect.addListener(
            function startHandshake(/** @type chrome.runtime.Port */ connection) {
                if (connection.name !== nydusConnection.id) return;
                nydusConnection.tabId = isBackground ? -1 : connection?.sender?.tab?.id ?? this.nydusTab;
                this._handleClientHandshake(connection, nydusConnection);

                if (onMessage) {
                    connection.onMessage.addListener(onMessage);
                }
                this._addConnectionOnDisconnectListeners(
                    connection,
                    nydusConnection.id.toString(),
                    nydusConnection.tabId,
                );
            }.bind(this),
        );
    }

    _canAccessTabs() {
        return typeof chrome.tabs !== 'undefined';
    }

    /**
     * @param {{type: string;id: any; tabId: number;}} message
     * @param {NydusConnection} nydusConnection
     */
    _handleConnectionHandshakeMessage(message, nydusConnection) {
        if (message.type !== NYDUS_CONNECTION_HANDSHAKE) return;

        const tabId = message.tabId;
        nydusConnection.tabId = tabId;
        nydusConnection.ready = true;

        this._doOnConnect(nydusConnection.connection);
        this._readyCheck();
    }

    /**
     * @param {chrome.runtime.Port} connection
     * @param {NydusConnection} nydusConnection
     */
    _handleClientHandshake(connection, nydusConnection) {
        nydusConnection.connection = connection;
        nydusConnection.ready = true;
        this._addConnectionToPool(nydusConnection.tabId, nydusConnection);
        this._sendHandshake(nydusConnection);
        this._doOnConnect(connection);
        this._readyCheck();
    }

    /**
     * Trigger the onConnect callback of the Nydus instance
     *
     * @param {chrome.runtime.Port} connection
     */
    _doOnConnect(connection) {
        if (this.onConnect) {
            this.onConnect(this, connection);
        }
    }

    /**
     * @param {NydusConnection} nydusConnection
     */
    _sendHandshake(nydusConnection) {
        const connectionInstance = this.connections[nydusConnection.tabId][nydusConnection.id];
        connectionInstance.connection?.postMessage({
            type: NYDUS_CONNECTION_HANDSHAKE,
            id: connectionInstance.id,
            tabId: nydusConnection.tabId,
        });
    }

    async _readyCheck() {
        if (await this._requirementsFulfilled()) {
            // Resolve the whenReady promise for those listening for it
            this._whenReadyResolver(this);
            this._doOnReady();
        }
    }

    /**
     * Trigger onReady, and pass the nydus instance to it
     * */
    _doOnReady() {
        if (this.ready) return; // If already was ready, don't re-trigger

        this.ready = true;
        if (this.onReady) this.onReady(this);
    }

    _getConnectionsFlat() {
        let connections = [];
        for (const connPool of Object.values(this.connections)) {
            for (const conn of Object.values(connPool)) {
                connections.push(conn);
            }
        }

        return connections;
    }

    async _requirementsFulfilled() {
        // Check that all required connections are built and ready
        const connectionsFlat = this._getConnectionsFlat();
        return connectionsFlat.every(conn => conn.ready);
    }
}

/**
 * Init.js contains the code which is run onto the devtools panel
 * as the devtools are opened.
 * */

let nydus;

initConnection();

function initConnection() {
    nydus = buildNydus({
        connections: [
            {
                id: CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT,
                onMessage: onNydusMessage,
                host: false,
            },
        ],
        onReady: onNydusReady,
        onConnect: onNydusConnect,
    });
}

chrome.runtime.onMessage.addListener(async message => {
    if (message.type === MESSAGE_TYPE.REFRESH && nydus && nydus.nydusTab === message.tabId) {
        document.dispatchEvent(new CustomEvent(message.type.toString(), { detail: message }));
        initConnection();
    }
});

/**
 * @param {Nydus} nydus
 */
function onNydusReady(nydus) {
    renderView();
    nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
        type: MESSAGE_TYPE.QUERY,
    });
}

/**
 * @param {{ type: { toString: () => string; }; }} message
 */
function onNydusMessage(message) {
    // Send the messages to devtools components using the DOM event API
    document.dispatchEvent(new CustomEvent(message.type.toString(), { detail: message }));
}

/**
 * @param {Nydus} nydus
 * @param {chrome.runtime.Port} connection
 */
function onNydusConnect(nydus, connection) {
    addListeners(connection);
}

function renderView() {
    document.querySelector('.loading')?.remove();
    V(
        T`
            <custom-elements-list></custom-elements-list>
            <custom-elements-inspector></custom-elements-inspector>
        `,
        document.body,
    );
}

/**
 * @param {chrome.runtime.Port} port
 */
function addListeners(port) {
    const forwardEvent = (/** @type { CustomEvent } */ e) => {
        port.postMessage(e.detail);
    };

    FORWARD_EVENTS.forEach(ev => {
        document.addEventListener(ev, forwardEvent);
    });

    port.onDisconnect.addListener(() => {
        FORWARD_EVENTS.forEach(ev => {
            document.removeEventListener(ev, forwardEvent);
        });
    });
}

const FORWARD_EVENTS = ['__WC_DEV_TOOLS_LOG', '__WC_DEV_TOOLS_LOG_OBJECT', '__WC_DEV_TOOLS_POST_MESSAGE'];

// Handle timeouts
setTimeout(() => {
    const loader = document.querySelector('.loading');
    if (loader) {
        // Reload the window if it hung
        window.location.reload();
    }
}, 4000);
