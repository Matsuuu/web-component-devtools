// Events
const QUERY_REQUEST = "__WC_DEV_TOOLS_QUERY_REQUEST";
const QUERY_RESULT = "__WC_DEV_TOOLS_QUERY_RESULT";
const HIGHLIGHT_ELEMENT = "__WC_DEV_TOOLS_HIGHLIGHT_ELEMENT";
const SELECT_REQUEST = "__WC_DEV_TOOLS_SELECT_REQUEST";
const SELECT_RESULT = "__WC_DEV_TOOLS_SELECT_RESULT";
const UPDATE_PROPERTY_REQUEST = "__WC_DEV_TOOLS_UPDATE_PROPERTY";
const UPDATE_ATTRIBUTE_REQUEST = "__WC_DEV_TOOLS_UPDATE_ATTRIBUTE";
const INSPECT_REQUEST = "__WC_DEV_TOOLS_INSPECT_REQUEST";
const FUNCTION_CALL_REQUEST = "__WC_DEV_TOOLS_FUNCTION_CALL_REQUEST";
const MUTATION_EVENT = "__WC_DEV_TOOLS_MUTATION_EVENT";
const DOM_CREATED_EVENT = "__WC_DEV_TOOLS_DOM_CREATED_EVENT";

// Element Properties
const ELEMENT_DEPTH = "__WC_DEV_TOOLS_ELEMENT_DEPTH";
const ELEMENT_NAME = "__WC_DEV_TOOLS_ELEMENT_NAME";
const ELEMENT_SELECTED_INDEX = "__WC_DEV_TOOLS_SELECTED_INDEX";
const ELEMENT_INDEX = "__WC_DEV_TOOLS_ELEMENT_INDEX";
const ELEMENT_TYPE = "__WC_DEV_TOOLS_ELEMENT_TYPE";

// Window properties
const SELECTED_ELEMENT = "__WC_DEV_TOOLS_SELECTED_ELEMENT";
const SPOTLIGHT_ELEMENT = "__WC_DEV_TOOLS_SPOTLIGHT";
const CONTEXT_MENU_TARGET = "__WC_DEV_TOOLS_CONTEXT_MENU_TARGET";
const FOUND_ELEMENTS = "__WC_DEV_TOOLS_FOUND_ELEMENTS";
const SELECTED_ELEMENT_OBSERVER_DISCONNECTERS = "__WC_DEV_TOOLS_SELECTED_ELEMENT_OBSERVER_DISCONNECTERS";
const SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS = "__WC_DEV_TOOLS_SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS";

var CONSTANTS = /*#__PURE__*/Object.freeze({
    __proto__: null,
    QUERY_REQUEST: QUERY_REQUEST,
    QUERY_RESULT: QUERY_RESULT,
    HIGHLIGHT_ELEMENT: HIGHLIGHT_ELEMENT,
    SELECT_REQUEST: SELECT_REQUEST,
    SELECT_RESULT: SELECT_RESULT,
    UPDATE_PROPERTY_REQUEST: UPDATE_PROPERTY_REQUEST,
    UPDATE_ATTRIBUTE_REQUEST: UPDATE_ATTRIBUTE_REQUEST,
    INSPECT_REQUEST: INSPECT_REQUEST,
    FUNCTION_CALL_REQUEST: FUNCTION_CALL_REQUEST,
    MUTATION_EVENT: MUTATION_EVENT,
    DOM_CREATED_EVENT: DOM_CREATED_EVENT,
    ELEMENT_DEPTH: ELEMENT_DEPTH,
    ELEMENT_NAME: ELEMENT_NAME,
    ELEMENT_SELECTED_INDEX: ELEMENT_SELECTED_INDEX,
    ELEMENT_INDEX: ELEMENT_INDEX,
    ELEMENT_TYPE: ELEMENT_TYPE,
    SELECTED_ELEMENT: SELECTED_ELEMENT,
    SPOTLIGHT_ELEMENT: SPOTLIGHT_ELEMENT,
    CONTEXT_MENU_TARGET: CONTEXT_MENU_TARGET,
    FOUND_ELEMENTS: FOUND_ELEMENTS,
    SELECTED_ELEMENT_OBSERVER_DISCONNECTERS: SELECTED_ELEMENT_OBSERVER_DISCONNECTERS,
    SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS: SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS
});

/**
 * This is the web component for the element which highlights the focused element
 * from the web page. This is written in vanilla JS due to it being injected onto the document,
 * and we don't want to inject the whole of Lit etc. in there.
 * */
class SpotlightBorder extends HTMLElement {
    constructor() {
        super();

        const template = document.createElement('template');
        template.innerHTML = `
      <style>
        :host {
          --position-x: 0px;
          --position-y: 0px;
          --size-x: 0px;
          --size-y: 0px;

          --info-box-offset: -2.5rem;

          position: fixed;
          top: var(--position-y);
          left: var(--position-x);
          height: var(--size-y);
          width: var(--size-x);
          z-index: 9001;
          pointer-events: none;
          transition: 200ms ease-in-out;
        }

        .element-highlight {
          background: #a0c5e8;
          opacity: 0.6;
          height: 100%;
          width: 100%;
          position: relative;
        }

        .info-box {
            width: fit-content;
            height: fit-content;
            background: #2a4747;
            color: #FFF;
            position: absolute;
            bottom: var(--info-box-offset);
            left: 0;
            white-space: nowrap;
            padding: 0.3rem 0.6rem;
        }

        .info-box p {
            margin: 0;
            font-size: 1.1rem;
        }

        .info-box span {
            color: hotpink;
        }
      </style>

      <div class="element-highlight">
      </div>
          <div class="info-box"><p class="info-box-text"></p></div>
    `;

        this.position = { x: 0, y: 0 };
        this.size = { x: 0, y: 0 };

        const root = this.attachShadow({ mode: 'open' });
        root.appendChild(template.content.cloneNode(true));
    }

    /**
     * @param {string} name
     * @param {{ x: number; y: number; }} position
     * @param {{ x: number; y: number; }} size
     */
    updateSpotlight(name, position, size) {
        const isAboveViewport = position.y < 0;
        const isBelowViewport = position.y > window.visualViewport.height;
        if (!isAboveViewport && !isBelowViewport) {
            this.style.setProperty('--position-x', position.x + 'px');
            this.style.setProperty('--position-y', position.y + 'px');
            this.style.setProperty('--size-x', size.x + 'px');
            this.style.setProperty('--size-y', size.y + 'px');
            this.style.setProperty('--info-box-offset', '-2.5rem');
        } else {
            this.style.setProperty('--size-y', '0px');
            this.style.setProperty('--position-x', position.x + 'px');
            if (isAboveViewport) {
                this.style.setProperty('--position-y', '0px');
            }
            if (isBelowViewport) {
                this.style.setProperty('--position-y', window.visualViewport.height + 'px');
                this.style.setProperty('--info-box-offset', '0.25rem');
            }
        }

        this.updateInfoBox(name, position, size);
    }

    /**
     * @param {string} name
     * @param {{ x: number; y: number; }} position
     * @param {{ x: any; y: any; }} size
     */
    updateInfoBox(name, position, size) {
        this.shadowRoot.querySelector('.info-box-text').innerHTML = `<span>${name}</span>  |  ${size.x.toFixed(
            1,
        )}px x ${size.y.toFixed(1)}px`;
    }

    static init() {
        if (!customElements.get('wc-devtools-spotlight-border')) {
            customElements.define('wc-devtools-spotlight-border', SpotlightBorder);
        }
    }
}

/**
 * Quite a process-of-elimination way of detemining if the value, or the
 * wanted value of the field is a boolean
 *
 * @param {HTMLElement} element
 * @param {import("custom-elements-manifest/schema").Attribute} [attribute]
 */
function attributeIsBoolean(element, attribute) {
    if (attribute.type && attribute.type.text === 'boolean') return true;

    const value = element.getAttribute(attribute.name);
    if (element.hasAttribute(attribute.name) && value === '') return true;
    if (typeof value === 'boolean') return true;
    if (value === 'true' || value === 'false') return true;
    if (value != null && value.length <= 0) return true;

    return false;
}

function getCurrentSelectedElement() {
    return window[SELECTED_ELEMENT];
}

/**
 * Check if element is defined in the window context it is
 * placed into. This needs to be done since the element could be inside a
 * iframe.
 *
 * @param {HTMLElement} element
 */
function elementIsDefined(element) {
    const elementDocument = element.ownerDocument;
    const elementWindow = elementDocument.defaultView;

    return typeof elementWindow.customElements.get(element.nodeName.toLowerCase()) !== 'undefined';
}

/**
 * @param {HTMLElement} element
 */
function getElementDeclaration(element) {
    const elementDocument = element.ownerDocument;
    const elementWindow = elementDocument.defaultView;
    return elementWindow.customElements.get(element.nodeName.toLowerCase());
}

const crawlerUtilsInject = `
${attributeIsBoolean.toString()}
${getCurrentSelectedElement.toString()}
${elementIsDefined.toString()}
${getElementDeclaration.toString()}
`;

/**
 * For presumed vanilla elements, we take a look at the observedAttributes,
 * and go from there. Naively guessing the type of the element.
 *
 * In the Devtools UI, we will allow the user to change the type if it's wrong
 * and save it in some kind of database.
 *  @param {any} customElementDeclaration
 *  @param {HTMLElement} element
 *  @param {DevToolsElement} elementData
 */
function parseGenericComponent(customElementDeclaration, element, elementData) {
    determineAttributes(customElementDeclaration, elementData, element);
    mapAttributeValues(elementData, element);
    mapPropertyValues(elementData, element);
}

/**
    * Determine the attributes names and types by ducktyping.
    *
    * If a attribute is already declared from custom-elements-manifest, we
    * won't overwrite those, but just continue.
    *
 * @param {any} customElementDeclaration
 * @param {DevToolsElement} elementData
 * @param {HTMLElement} element
 */
function determineAttributes(customElementDeclaration, elementData, element) {
    const observedAttributes = customElementDeclaration.observedAttributes ?? [];

    if (!elementData.attributes) elementData.attributes = [];

    const existingAttributeKeys = elementData.attributes.map(at => at.name);
    for (const attrName of observedAttributes) {
        if (existingAttributeKeys.includes(attrName)) continue; // This attribute is already declared

        /** @type import('custom-elements-manifest/schema').Attribute */
        let attribute = { name: attrName };
        attribute.type = determineAttributeType(attribute, element);

        elementData.attributes.push(attribute);
    }
}

/**
 * Map the property values from the element to a map.
 * Expects the elementData.properties to have descriptions of properties.
 *
 * These can be either:
 * 1. Acquired from the custom-elements-manifest
 * 2. Be determined from the CustomElementsDeclaration
 *
 *  @param {DevToolsElement} elementData
 *  @param {HTMLElement} element
 * */
function mapPropertyValues(elementData, element) {
    const propertyValues = {};
    if (!elementData.properties) {
        elementData.propertyValues = propertyValues;
        return;
    }

    for (const prop of elementData.properties) {
        propertyValues[prop.name] = element[prop.name];
    }
    elementData.propertyValues = propertyValues;
}
/**
 * Map the attribute values from the element to a map.
 * Expects the elementData.properties to have descriptions of properties.
 *
 * These can be either:
 * 1. Acquired from the custom-elements-manifest
 * 2. Be determined from the CustomElementsDeclaration
 *
 *  @param {DevToolsElement} elementData
 *  @param {HTMLElement} element
 * */
function mapAttributeValues(elementData, element) {
    const attributeValues = {};
    if (!elementData.attributes) {
        elementData.attributeValues = attributeValues;
        return;
    }
    for (const attr of elementData.attributes) {
        let attrType = determineAttributeType(attr, element);
        switch (attrType.text) {
            case 'boolean':
                attributeValues[attr.name] = element.hasAttribute(attr.name);
                break;
            case 'string':
            default:
                attributeValues[attr.name] = element.getAttribute(attr.name);
                break;
        }
    }
    elementData.attributeValues = attributeValues;
}

/**
 * @param {import("custom-elements-manifest/schema").Attribute} attribute
 * @param {HTMLElement} element
 */
function determineAttributeType(attribute, element) {
    if (attribute.type) return attribute.type;
    return attributeIsBoolean(element, attribute) ? { text: 'boolean' } : { text: 'string' };
}

/**
 * @param {{ observedAttributes: any; }} customElementDeclaration
 * @param {HTMLElement} element
 */
function mapObservedAttributes(customElementDeclaration, element) {
    const attributes = [];
    const attributeValues = {};
    const observedAttributes = customElementDeclaration.observedAttributes;
    if (!observedAttributes) return { attributes, attributeValues };
    for (const name of observedAttributes) {
        let type = { text: 'string' };
        /** @type {any} */
        let value = element.getAttribute(name);

        if (value == null) {
            // If the attribute is null, we can check the actual property
            // value, and in case there is one set, we can ducktype from that
            const propValue = element[name];
            if (propValue != null) value = propValue;
        }

        if (attributeIsBoolean(value)) {
            type = { text: 'boolean' };
            value = value === '' || value === 'true';
        }

        attributes.push({
            name,
            type,
        });
        attributeValues[name] = value;
    }
    return { attributes, attributeValues };
}

/**
 * Lit declares the properties in a _classProperties -field in the custom element class declaration.
 * We can map the properties here before we pass them to the default behavior to scrape the data
 *
 * @param {any} customElementDeclaration
 * @param {HTMLElement} element
 * @param {DevToolsElement} elementData
 */
function parseLitElement(customElementDeclaration, element, elementData) {

    /** @type Array<import('custom-elements-manifest/schema').ClassField> */
    const properties = [];
    const classProperties = customElementDeclaration._classProperties;

    for (const [name, property] of classProperties) {
        properties.push({
            name,
            kind: 'field',
            type: { text: property.type?.name?.toLowerCase() ?? String.name.toLowerCase() },
        });

    }
    if (!elementData.properties) elementData.properties = [];
    elementData.properties = [...elementData.properties, ...properties];

    // Do the default action to map attributes
    parseGenericComponent(customElementDeclaration, element, elementData);
}

const parserScriptsInject = `
${parseGenericComponent.toString()}
${parseLitElement.toString()}
${mapObservedAttributes.toString()}
${mapPropertyValues.toString()}
${mapAttributeValues.toString()}
${determineAttributes.toString()}
${determineAttributeType.toString()}
`;

/**
 * @typedef UpdateData
 * @property {number} type
 * @property {number} index
 * @property {string} name
 * @property {any} value
 * @property {number} elementType
 * @property {import('custom-elements-manifest/schema').PropertyLike | import('custom-elements-manifest/schema').Attribute} attributeOrProperty
 * @property {Array<String>} propertyPath
 */

/**
 * @param {UpdateData} updateData
 * @param {string} updateTarget Property or Attribute
 */
function updateGenericComponentValue(updateData, updateTarget) {
    /** @type { HTMLElement } */
    const element = getCurrentSelectedElement();
    const attributeOrProperty = updateData.attributeOrProperty;
    const attributeOrPropertyName = updateData.attributeOrProperty.name;
    switch (updateTarget) {
        case 'attribute':
            const isBoolean = attributeIsBoolean(element, attributeOrProperty);
            if (isBoolean) {
                if (updateData.value) element.setAttribute(attributeOrPropertyName, '');
                else element.removeAttribute(attributeOrPropertyName);
            } else {
                if (updateData.value && updateData.value.length > 0)
                    element.setAttribute(attributeOrPropertyName, updateData.value);
                else element.removeAttribute(attributeOrPropertyName);
            }
            break;
        case 'property':
            if (!updateData.propertyPath || updateData.propertyPath.length <= 0) {
                element[attributeOrPropertyName] = updateData.value;
            } else {
                let targetObject = element;
                while (updateData.propertyPath.length > 0) {
                    targetObject = targetObject[updateData.propertyPath.shift()];
                }
                targetObject[attributeOrPropertyName] = updateData.value;
            }
            break;
    }
}

/**
 * @param {UpdateData} updateData
 * @param {string} updateTarget Property or Attribute
 */
function updateLitElementValue(updateData, updateTarget) {
    updateGenericComponentValue(updateData, updateTarget);

    if (updateTarget === 'property') {
        const element = getCurrentSelectedElement();
        element.requestUpdate();
    }
}

const elementUpdatersInject = `
${updateGenericComponentValue.toString()}
${updateLitElementValue.toString()}
`;

/**
 * @typedef ElementTypeMap
 * @type {Object.<string, ElementType>}
 *
 * @callback ParserCallback
 * @param {any} customElementDeclaration
 * @param {HTMLElement} element
 * @param {DevToolsElement} elementData
 *
 * @callback OnUpdateCallback
 * @param {import("./element-updaters").UpdateData} UpdateData
 * @param {string} updateTarget Attribute or Property
 *
 * @typedef ElementType
 * @property {number} id
 * @property {ParserCallback} parser
 * @property {OnUpdateCallback} onUpdate
 * */

/**
 * @param {number} id
 */
function getElementTypeById(id) {
    for (const [_, val] of Object.entries(ELEMENT_TYPES)) {
        if (val.id === id) return val;
    }
    return null;
}

/**
 * @param {any} customElementDeclaration
 */
function determineElementType(customElementDeclaration) {
    if (hasLitProperties(customElementDeclaration)) return ELEMENT_TYPES.LIT;

    return ELEMENT_TYPES.VANILLA;
}

/**
 * @param {{ _classProperties: any; }} customElementDeclaration
 */
function hasLitProperties(customElementDeclaration) {
    return typeof customElementDeclaration._classProperties !== 'undefined';
}

const elementTypesInject = `
${getElementTypeById.toString()}
${determineElementType.toString()}
${hasLitProperties.toString()}

const ELEMENT_TYPES = {
    VANILLA: {
        id: 0,
        parser: parseGenericComponent,
        onUpdate: updateGenericComponentValue,
    },
    LIT: {
        id: 1,
        parser: parseLitElement,
        onUpdate: updateLitElementValue,
    },
};
`;

/**
 * Copy the values here into the elementTypesInject export in string
 * format so that they get copied to client side
 *
 *   @type ElementTypeMap
 * */
const ELEMENT_TYPES = {
    VANILLA: {
        id: 0,
        parser: parseGenericComponent,
        onUpdate: updateGenericComponentValue,
    },
    LIT: {
        id: 1,
        parser: parseLitElement,
        onUpdate: updateLitElementValue,
    },
};

/**
 * @typedef FoundElement
 * @property {string} name
 * @property {number} index
 * @property {number} __WC_DEV_TOOLS_ELEMENT_DEPTH
 *
 * */

/**
 * @typedef {FoundElement} FoundElementWithRefFields
 * @property {HTMLElement} element
 *
 * @typedef {FoundElement & FoundElementWithRefFields} FoundElementWithRef
 * */

/**
 * ParseElements goes through the Custom Element DOM nodes
 * and maps them into 3 separate collections:
 *
 * - elementsArray for listing the elements in the DevTools
 * - elementsRefArray for accessing the same nodes in the browser window
 * - elementsMap for separated collection of unique components
 *
 *   elementsRefArray is stored in the __WC_DEV_TOOLS_FOUND_ELEMENTS -window-object
 *
 * @param {Array<HTMLElement>} elements
 * */
function parseElements(elements) {
    const elementsMap = {};
    const elementsArray = [];
    // ElementsRefArray contains references to the actual DOM
    // objects, which can't be passed to the devtools window, but
    // are useful when we later on modify the values of DOM nodes.
    const elementsRefArray = [];

    for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        element[ELEMENT_INDEX] = i;
        const elementName = element.nodeName.toLowerCase();

        /** @type { FoundElement } */
        const elementData = {
            name: elementName,
            index: i,
            __WC_DEV_TOOLS_ELEMENT_DEPTH: element[ELEMENT_DEPTH],
        };

        elementsArray.push(elementData);
        elementsRefArray.push({ ...elementData, element });

        if (!elementsMap[elementName]) {
            elementsMap[elementName] = elementData;
        }
    }


    return { elementsArray, elementsMap, elementsRefArray };
}

/**
 * parseElementProperties determines the type of component we're inspecting,
 * what it's custom properties/attributes are, and what their values are, respecting gettings/setters.
 * @param {HTMLElement} element
 * @param {DevToolsElement} elementData
 *
 * @returns {DevToolsElement}
 */
function parseElementProperties(element, elementData) {
    /** @type DevToolsElement */
    const customElementDeclaration = getElementDeclaration(element);

    if (!customElementDeclaration) return elementData;

    const elementType = determineElementType(customElementDeclaration);

    if (!elementData.parentClass) {
        elementData.parentClass = {
            name: Object.getPrototypeOf(element.constructor).name,
            kind: 'class',
        };
    }
    elementData.typeInDevTools = elementType.id;

    // Parse data with the proper parser for the type and sets it to elementState
    elementType.parser(customElementDeclaration, element, elementData);
    return elementData;
}

const parserInject = `
${parseElementProperties.toString()}
${parseElements.toString()}

`;

/**
 * @typedef FoundComponentExt
 * @property { Array } __WC_DEV_TOOLS_CHILD_COMPONENTS
 *
 * @typedef { HTMLElement & FoundComponentExt } FoundComponent
 *
 * */

function findCustomElements() {
    return findAllElements(document.body);
}

/**
 * @param {HTMLElement | ShadowRoot} elem
 *
 * @returns {Array<HTMLElement>} elements
 */
function findAllElements(elem) {
    let elements = /** @type { Array<HTMLElement> } */ (Array.from(elem.querySelectorAll('*')));

    for (const e of elements) {
        if (e.shadowRoot) {
            elements = [...elements, ...findAllElements(e.shadowRoot)];
        }
        if (e.nodeName === 'IFRAME') {
            // @ts-ignore
            try {
                elements = [...elements, ...findAllElements(e.contentWindow.document)];
            } catch (err) {
                // Couldn't access iframe
                console.warn("[WebComponentDevTools]: Couldn't access iframe ", e);
            }
        }
    }

    return elements.filter(
        elem =>
            elem.nodeName.includes('-') && elementIsDefined(elem) && elem.nodeName.toLowerCase() !== 'wc-devtools-spotlight-border',
    );
}

function findElementsOnPage() {
    let customElements = findCustomElements();
    calculateElementDepths(customElements);

    const parsedElements = parseElements(customElements);
    window[FOUND_ELEMENTS] = parsedElements.elementsRefArray;

    return parsedElements;
}

function getCachedFoundElements() {
    return window[FOUND_ELEMENTS];
}

/**
 * @param {Array<HTMLElement>} elements
 */
function calculateElementDepths(elements) {
    elements.forEach(elem => {
        let depth = 0;
        let el = elem.parentElement;
        while (el) {
            if (el.nodeName.includes('-')) {
                depth++;
            }
            // @ts-ignore
            el = el.parentElement ?? el.getRootNode()?.host ?? null;
        }
        elem[ELEMENT_DEPTH] = depth;
    });
}

function getScrollingParent(elem) {
    if (elem == null) {
        return null;
    }
    if (elem.scrollHeight > elem.clientHeight) {
        return elem;
    } else {
        return getScrollingParent(elem.parentNode ?? elem.host);
    }
}

/**
 * @param {number} index
 * @returns { HTMLElement }
 */
function getElementByIndex(index) {
    /** @type {import("./element-parser.js").FoundElementWithRefFields} */
    const elements = window[FOUND_ELEMENTS];

    const spotlitElement = elements[index]?.element;
    return spotlitElement;
}

// Quick and dirty way to append code on the page
// We could do better

const finderScriptsInject = `
${findCustomElements.toString()}
${calculateElementDepths.toString()}
${findAllElements.toString()}
${getElementByIndex.toString()}
${getScrollingParent.toString()}
${getCachedFoundElements.toString()}
${findElementsOnPage.toString()}
`;

function spyEvents(targetElement, events) {
    disconnectEventListenersFromSelected();
    events?.forEach(event => {
        const triggerEvent = () => {
            const eventData = {
                detail: {
                    action: "EVENT",
                    eventData: {
                        event
                    }
                }
            };
            document.dispatchEvent(new CustomEvent(DOM_CREATED_EVENT, eventData));
        };
        targetElement.addEventListener(event.name, triggerEvent);
        addSelectedElementEventListenerDisconnecter(() => targetElement.removeEventListener(event.name, triggerEvent));
    });
}


function disconnectEventListenersFromSelected() {
    if (!window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS]) return;

    window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS].forEach(disc => disc());
    window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS] = [];
}

function addSelectedElementEventListenerDisconnecter(disconnecter) {
    if (!window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS]) {
        window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS] = [];
    }
    window[SELECTED_ELEMENT_EVENT_LISTENER_DISCONNECTERS].push(disconnecter);
}

const eventObserversInject = `
${spyEvents.toString()}
${disconnectEventListenersFromSelected.toString()}
${addSelectedElementEventListenerDisconnecter.toString()}
`;

let mutationListStack = [];


function handleSelectMutationObservers(selectedElement) {
    disconnectObserversFromSelected();
    const mutatorConfig = { childList: true, subtree: true, attributes: true };
    if (selectedElement.shadowRoot) {
        addSelectedElementObserverDisconnecter(listenForMutations(selectedElement.shadowRoot, mutatorConfig, true));
    }
    addSelectedElementObserverDisconnecter(listenForMutations(selectedElement, mutatorConfig, true));
}

function disconnectObserversFromSelected() {
    if (!window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS]) return;

    window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS].forEach(disc => disc());
    window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS] = [];
}

function addSelectedElementObserverDisconnecter(disconnecter) {
    if (!window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS]) {
        window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS] = [];
    }
    window[SELECTED_ELEMENT_OBSERVER_DISCONNECTERS].push(disconnecter);
}

function listenForMutations(targetNode, config, alwaysReSelect = false) {
    // TODO(Matsuuu): Clean this mess
    const observer = new MutationObserver((mutationList, observer) => {
        throttle(mutationList, () => handleMutationEvent(mutationList, observer, targetNode, config, alwaysReSelect));
    });

    observer.observe(targetNode, config);
    return () => observer.disconnect();
}

/**
 * @param {MutationRecord[]} mutationList
 * @param {MutationObserver} observer
 * @param {HTMLElement} targetNode
 * @param {any} config
 * @param {boolean} alwaysReSelect
 */
function handleMutationEvent(mutationList, observer, targetNode, config, alwaysReSelect) {
    const isRelevantQueryEvent = checkIfMutationIsRelevantQueryEvent(mutationListStack);
    if (isRelevantQueryEvent) {
        document.dispatchEvent(new CustomEvent(MUTATION_EVENT, { detail: { action: 'QUERY' } }));
    }

    const currentTarget = getCurrentSelectedElement();
    const isRelevantReSelectEvent = checkIfMutationIsRelevantReSelectEvent(mutationListStack, currentTarget);
    if (alwaysReSelect || isRelevantReSelectEvent) {
        const eventData = {
            detail: {
                action: 'RESELECT',
                target: {
                    indexInDevTools: currentTarget[ELEMENT_INDEX],
                    name: currentTarget.nodeName.toLowerCase(),
                    tagName: currentTarget.nodeName.toLowerCase(),
                },
            },
        };
        document.dispatchEvent(new CustomEvent(MUTATION_EVENT, eventData));
    }
}

let throttling = false;

function throttle(mutationList, callback) {
    if (throttling) {
        mutationListStack = [...mutationListStack, ...mutationList];
        return;
    }
    mutationListStack = mutationList;
    throttling = true;
    setTimeout(() => {
        callback();
        throttling = false;
    }, 50);
}

function checkIfMutationIsRelevantQueryEvent(mutationList) {
    let isRelevant = true;
    if (mutationList.every(mut => mut.target.nodeName === 'WC-DEVTOOLS-SPOTLIGHT-BORDER')) {
        isRelevant = false;
    }

    return isRelevant;
}

function checkIfMutationIsRelevantReSelectEvent(mutationList, currentTarget) {
    if (!currentTarget) return false;

    let isRelevant = false;
    if (mutationList.some(mut => mut.target === currentTarget)) {
        isRelevant = true;
    }

    return isRelevant;
}

const mutationInject = `
let throttling = false;
let mutationListStack = [];
${listenForMutations.toString()}
${checkIfMutationIsRelevantQueryEvent.toString()}
${checkIfMutationIsRelevantReSelectEvent.toString()}
${throttle.toString()}
${handleMutationEvent.toString()}
${disconnectObserversFromSelected.toString()}
${addSelectedElementObserverDisconnecter.toString()}
${handleSelectMutationObservers.toString()}
`;

/**
 * @param {MouseEvent} e
 */
function updateLatestContextMenuHit(e) {
    /** @type { HTMLElement } */
    let clickedElem = null;
    let clickedWebComponent = null;
    const clickPath = e.composedPath();

    while (clickPath.length > 0 && !clickedWebComponent) {
        clickedElem = /** @type { HTMLElement } */ (clickPath.shift());
        if (clickedElem.nodeName && customElements.get(clickedElem.nodeName.toLowerCase())) {
            clickedWebComponent = clickedElem;
        }
    }

    window[CONTEXT_MENU_TARGET] = clickedWebComponent;
}

function getContextMenuTarget() {
    return window[CONTEXT_MENU_TARGET];
}

function callFunction(event) {
    const method = event.detail.method;
    const targetElement = getElementByIndex(event.detail.targetIndex);

    if (method.parameters) {
        targetElement[method.name].call(targetElement, ...event.detail.parameters);
    } else {
        targetElement[method.name].call(targetElement);
    }
}

function inspectElement() {
    const targetElement = getContextMenuTarget();
    let elementsOnPage = getCachedFoundElements();
    if (!elementsOnPage) {
        const parsedElements = findElementsOnPage();
        elementsOnPage = parsedElements.elementsRefArray;
    }

    let elementToInspect = null;
    for (const elem of elementsOnPage) {
        if (elem.element === targetElement) {
            elementToInspect = elem;
        }
    }

    // TODO(Matsuuu): Open up WC dev tools if possible
    if (elementToInspect) {
        const eventData = {
            detail: {
                action: 'SELECT',
                target: {
                    indexInDevTools: elementToInspect.index,
                    name: elementToInspect.element.nodeName.toLowerCase(),
                    tagName: elementToInspect.element.nodeName.toLowerCase(),
                },
            },
        };
        document.dispatchEvent(new CustomEvent(DOM_CREATED_EVENT, eventData));
    }
}

function queryElements() {
    const parsedElements = findElementsOnPage();

    const eventData = {
        detail: {
            elementsArray: parsedElements.elementsArray,
            elementsMap: parsedElements.elementsMap,
        },
    };
    document.dispatchEvent(new CustomEvent(QUERY_RESULT, eventData));
}

/**
 * @param {import("./element-updaters.js").UpdateData} updateData
 */
function updateElementProperty(updateData) {
    const elementType = getElementTypeById(updateData.elementType);
    elementType.onUpdate(updateData, 'property');
}

/**
 * @param {import('./element-updaters.js').UpdateData} updateData
 */
function updateElementAttribute(updateData) {
    const elementType = getElementTypeById(updateData.elementType);
    elementType.onUpdate(updateData, 'attribute');
}

/**
 * @param {Number} index
 */
function highlightElement(index) {
    /** @type {import("../elements/spotlight-border.js").SpotlightBorder} */
    let spotlight = window[SPOTLIGHT_ELEMENT];
    if (!spotlight) {
        spotlight =
            /** @type {import("../elements/spotlight-border.js").SpotlightBorder} */
            (document.createElement('wc-devtools-spotlight-border'));

        SpotlightBorder.init();
        document.body.appendChild(spotlight);
        window[SPOTLIGHT_ELEMENT] = spotlight;
    }

    if (index >= 0) {
        spotlight.style.visibility = 'visible';
        const spotlitElement = getElementByIndex(index);
        const spotlitElementWindow = spotlitElement.ownerDocument.defaultView;

        const domRect = spotlitElement.getBoundingClientRect();
        let topOffset = domRect.top;
        let leftOffset = domRect.left;

        if (window !== spotlitElementWindow) {
            const iframeBoundingRect = spotlitElementWindow.frameElement.getBoundingClientRect();
            topOffset += iframeBoundingRect.top;
            leftOffset += iframeBoundingRect.left;
        }

        spotlight.updateSpotlight(
            spotlitElement.localName,
            {
                x: leftOffset,
                y: topOffset
            },
            {
                x: domRect.width,
                y: domRect.height,
            },
        );
    } else {
        // If the element wants to highlight "-1", it means "Turn off the highlight"
        spotlight.updateSpotlight('', { x: 0, y: 0 }, { x: 0, y: 0 });
        spotlight.style.visibility = 'hidden';
    }
}

/**
 * Selects the given element by index and returns the property values of the element
 * @param {any} eventData
 */
function selectElement(eventData) {
    const selectedElement = getElementByIndex(eventData.indexInDevTools);
    if (selectedElement !== window[SELECTED_ELEMENT]) {
        // If wasn't re-select
        window[SELECTED_ELEMENT] = selectedElement;
        handleSelectMutationObservers(selectedElement);
        spyEvents(selectedElement, eventData.events);
    }

    const elementProperties = parseElementProperties(selectedElement, eventData);
    const viableData = {};
    removeUnsendableObjects(viableData, elementProperties);

    const returnEventData = { detail: viableData };

    document.dispatchEvent(new CustomEvent(SELECT_RESULT, returnEventData));
}

/**
 * Removes some of the unwanted nasties we don't want to show in the
 * devtools and tries to parse a nice new object from the vals.
 * */
function removeUnsendableObjects(returnData, elementProperties, cache = [], layer = 0) {
    if (layer > 100) {
        // Fallback to avoid stack overflow
        return;
    }
    for (const [key, val] of Object.entries(elementProperties)) {
        // Remove nodes, function and already cached object values (most likely circulars)
        if (
            val instanceof Node ||
            typeof val === 'function' ||
            (typeof val === 'object' && val != null && cache.includes(val))
        ) {
            delete returnData[key];
            continue;
        }

        if (typeof val === 'object' && val != null) {
            returnData[key] = Array.isArray(val) ? [...val] : { ...val };
            cache.push(val);
            removeUnsendableObjects(returnData[key], val, cache, layer + 1);
        } else {
            returnData[key] = val;
        }
    }
}

const domActionsInject = `
${updateLatestContextMenuHit.toString()}
${inspectElement.toString()}
${queryElements.toString()}
${updateElementProperty.toString()}
${highlightElement.toString()}
${selectElement.toString()}
${getContextMenuTarget.toString()}
${callFunction.toString()}
${updateElementAttribute.toString()}
${removeUnsendableObjects.toString()}
`;

function initDomQueryListener() {
    document.addEventListener(QUERY_REQUEST, queryElements);
    document.addEventListener(HIGHLIGHT_ELEMENT, (/** @type CustomEvent */ e) => highlightElement(e.detail.index));
    document.addEventListener(SELECT_REQUEST, (/** @type CustomEvent */ e) => selectElement(e.detail));

    document.addEventListener(UPDATE_PROPERTY_REQUEST, (/** @type CustomEvent */ e) => updateElementProperty(e.detail));

    document.addEventListener(UPDATE_ATTRIBUTE_REQUEST, (/** @type CustomEvent */ e) =>
        updateElementAttribute(e.detail),
    );

    document.addEventListener('contextmenu', e => updateLatestContextMenuHit(e));

    document.addEventListener(INSPECT_REQUEST, inspectElement);

    document.addEventListener(FUNCTION_CALL_REQUEST, callFunction);
}

const crawlerListenersInject = `
${initDomQueryListener.toString()}
`;

const crawlerInject = `
/**
* This is a content script injected by the Web Component Devtools
* to assist with DOM operations and other actions.
* */

${finderScriptsInject}
${crawlerListenersInject}
${crawlerUtilsInject}
${parserInject}
${elementTypesInject}
${elementUpdatersInject}
${domActionsInject}

// Parsers
${parserScriptsInject}
// Updaters
${elementUpdatersInject}
// Mutation
${mutationInject}
// Events
${eventObserversInject}
// Constants
${constantInjecter(CONSTANTS)}

// Init
initDomQueryListener();
listenForMutations(document.body, { childList: true, subtree: true });
`;

/**
 * We work with a lot of constants here, and we want to get them into the injected script.
 * Therefore we must declare them again in the injected string, since we cannot just simply
 * inject them as is.
 * */
function constantInjecter(constantsObject) {
    const constantKeys = Object.keys(constantsObject);
    let injectionString = '';

    constantKeys.forEach(constKey => {
        injectionString += `const ${constKey} = "${constantsObject[constKey].toString()}";\n`;
    });

    return injectionString;
}

/**
 * @typedef {number} DevToolsMessageType
 * */

const MESSAGE_TYPE = {
    LOG: 0,
    LOG_OBJECT: 1,
    INIT: 2,
    QUERY: 3,
    QUERY_RESULT: 4,
    HIGHLIGHT: 5,
    SELECT: 6,
    SELECT_RESULT: 7,
    REFRESH: 8,
    UPDATE_PROPERTY: 9,
    UPDATE_ATTRIBUTE: 10,
    PANEL_OPENED: 11,
    INSPECT: 12,
    CALL_FUNCTION: 13,
    TRIGGER_EVENT: 14
};

const CONNECTION_CHANNELS = {
    DEVTOOLS_PANEL_TO_CONTENT: "Lit DevTools - Panel to Content",
    DEVTOOLS_INITIALIZER: "Lit DevTools - Initializer",
    DEVTOOLS_BACKGROUND_CONTENT: "Lit DevTools - Background to Content",
    DEVTOOLS_CONTEXT_MENU_TO_BACKGROUND: "Lit DevTools - Context Menus to Background"
};

/**
 * @typedef NydusOptions
 * @property {Array<NydusConnectionOptions>} connections
 * @property {NydusCallback} [onReady]
 * @property {NydusConnectCallback} [onConnect]
 * @property{boolean} [isBackground]
 * */

/**
 *   @callback NydusConnectCallback
 *   @param {Nydus} nydus
 *   @param {chrome.runtime.Port} connection
 * */

/**
 * @typedef NydusConnectionPool
 * @type Object.<string, NydusConnection>
 * */

/**
 * @typedef NydusConnectionPoolTabMap
 * @type Object.<number, NydusConnectionPool>
 * */

/**
 * @typedef NydusConnection
 * @property {string | number} id
 * @property {number} [tabId]
 * @property {chrome.runtime.Port} [connection]
 * @property {NYDUS_CONNECTION_ROLE} role
 * @property {boolean} ready
 * */

/**
 * @typedef NydusConnectionOptions
 * @property {string | number} id
 * @property {OnMessageCallback} [onMessage]
 * @property {boolean} host
 * @property {boolean} [isBackground]
 * */

/**
 * @readonly
 * @enum {number} NydusConnectionRole
 * */
const NYDUS_CONNECTION_ROLE = {
    HOST: 0,
    CLIENT: 1,
};

const NYDUS_CONNECTION_HANDSHAKE = 'NYDUS_CONNECTION_HANDSHAKE';
const NYDUS_TAB_PING = 'NYDUS_TAB_PING';

/**
 * @param {NydusOptions} nydusOptions
 *
 * @returns {Nydus} nydus;
 */
function buildNydus(nydusOptions) {
    const nydus = new Nydus(nydusOptions);

    return nydus;
}

/**
 * @callback NydusCallback
 * @param {Nydus} nydus
 * */

/**
 * @callback OnMessageCallback
 * @param {any} message
 * */

/**
 *  A Routing / Orchestration tool for concurrent connections between dev tools closures
 * */
class Nydus {
    /**
     * @param {NydusOptions} nydusOptions
     */
    constructor(nydusOptions) {
        /** @type {Array<NydusConnectionOptions>} */
        this.connectionOptions = nydusOptions.connections;
        /** @type {NydusCallback} */
        this.onReady = nydusOptions.onReady;
        /** @type {NydusConnectCallback} */
        this.onConnect = nydusOptions.onConnect;

        /** @type { NydusConnectionPoolTabMap } */
        this.connections = {};
        /** @type {boolean} */
        this.ready = false;

        this._whenReadyResolver = null;
        this.whenReady = new Promise(resolve => {
            this._whenReadyResolver = resolve;
        });

        this._needsToSpecifyTab = this._canAccessTabs();
        this.nydusTab = null;

        this._createAllConnections();
    }

    async _createAllConnections() {
        await this._determineTabIds();
        this.connectionOptions.forEach(connectionOpts => {
            this.addConnection(
                connectionOpts.id,
                !connectionOpts.host,
                connectionOpts.onMessage,
                connectionOpts.isBackground,
            );
        });
    }

    /**
     *
     * Communication is important to keep tab-specific so that if the user has
     * 2 instances of WC DevTools open, they don't mix up each other.
     *
     * If the view has access to chrome.tabs, it means they are a background
     * task, and can easily query the tab. These ones will we make "Hosts" to
     * provide the tab info to others.
     *
     * Then others who can't access chrome.tabs, will send a one time message,
     * hoping for an answer to this question.
     *
     * This function is promisified so that we can make sure we have caught a tab ID before
     * proceeding with other actions.
     * */
    _determineTabIds() {
        return new Promise(resolve => {
            if (chrome.tabs) {
                chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
                    if (request.type === NYDUS_TAB_PING) {
                        sendResponse({ type: NYDUS_TAB_PING, tabId: sender.tab?.id });
                    }
                });
                chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
                    this.nydusTab = tabs[0]?.id ?? chrome.devtools.inspectedWindow.tabId;
                    resolve();
                });
            } else {
                chrome.runtime.sendMessage({ type: NYDUS_TAB_PING }, response => {
                    this.nydusTab = response.tabId;
                    resolve(response.tabId);
                });
            }
        });
    }

    /**
     * Add a connection to the Nydus with a given ID
     *
     * @param {number | string} connectionId
     * @param {boolean} isClient
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    addConnection(connectionId, isClient, onMessage, isBackground = false) {
        if (this.connections[connectionId]) return; // No duplicates

        const nydusConnection = {
            id: connectionId,
            role: isClient ? NYDUS_CONNECTION_ROLE.CLIENT : NYDUS_CONNECTION_ROLE.HOST,
            ready: false,
        };

        this._doConnectionHandshake(nydusConnection, onMessage, isBackground);
    }

    /**
     * Add a connection to Nydus as a host connector.
     *
     * Being a host means that you createa connection, and expect
     * a client to be listening for it, and approve it with a handshake.
     *
     * @param {string | number} connectionId
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    addHostConnection(connectionId, onMessage, isBackground = false) {
        this.addConnection(connectionId, false, onMessage, isBackground);
    }

    /**
     * Add a connection to Nydus as a client connector.
     *
     * Being a client means that you are listening for a Host
     * to create a connection, and then after a handshake can communicate
     *
     * @param {string | number} connectionId
     * @param {OnMessageCallback} onMessage
     */
    addClientConnection(connectionId, onMessage) {
        this.addConnection(connectionId, true, onMessage, false);
    }

    /**
     * Messages the desired Nydus Connection is one
     * is found with the name/id provided
     *
     * @param {string | number} recipient
     * @param {any} message
     */
    async message(recipient, message) {
        await this.whenReady;

        const tabId = await this._tryGetCurrentTab();
        let connPool = this.connections[tabId] ?? this.connections[-1];
        if (!connPool) {
            console.warn('[WebComponentDevTools]: Message send missed. Tab connection pool not found.', {
                recipient,
                message,
                tabId,
            });
            return;
        }

        const conn = connPool[recipient]?.connection;
        if (!conn) {
            console.warn('[WebComponentDevTools]: Message send missed. Connection not found.', {
                recipient,
                message,
                tabId,
            });
            return;
        }
        conn.postMessage({ ...message, tabId });
    }

    /**
     * Messages all of the connections in the Nydus Connection Pool
     *
     * @param {any} message
     */
    messageAll(message) {
        Object.values(this.connections).forEach(connPool => {
            connPool.forEach((/** @type {NydusConnection} */ conn) => {
                conn.connection.postMessage(message);
            });
        });
    }

    /**
     * Awaitable timeout
     *
     * @param {number} ms
     */
    _delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    _doConnectionHandshake(nydusConnection, onMessage, isBackground) {
        if (nydusConnection.role === NYDUS_CONNECTION_ROLE.HOST) {
            this._doHostHandshake(nydusConnection, onMessage, isBackground);
        } else {
            this._doClientHandshake(nydusConnection, onMessage, isBackground);
        }
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     * @param {boolean} isBackground
     */
    async _doClientHandshake(nydusConnection, onMessage, isBackground) {
        // We delay the connector init a bit to avoid race conditions
        // This could maybe be removed later, but needs testing
        await this._delay(100);

        const connection = await this._createConnection(nydusConnection, isBackground);
        nydusConnection.connection = connection;

        connection.onMessage.addListener(
            function finishHandshake(/** @type {any} */ message) {
                this._handleConnectionHandshakeMessage(message, nydusConnection);
                connection.onMessage.removeListener(finishHandshake);
                if (onMessage) {
                    connection.onMessage.addListener(onMessage);
                }
            }.bind(this),
        );
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {boolean} isBackground
     */
    _createConnection(nydusConnection, isBackground) {
        return new Promise(async resolve => {
            let connection;
            let tabId;
            // In devtools context we need to specify which tab to target
            if (this._canAccessTabs() && !isBackground) {
                tabId = await this._tryGetCurrentTab();
                connection = chrome.tabs.connect(tabId, {
                    name: nydusConnection.id.toString(),
                });
            } else {
                tabId = -1;
                connection = chrome.runtime.connect({
                    name: nydusConnection.id.toString(),
                });
            }
            this._addConnectionToPool(tabId, nydusConnection);
            this._addConnectionOnDisconnectListeners(connection, nydusConnection.id.toString(), tabId);
            resolve(connection);
        });
    }

    /**
     * @param {chrome.runtime.Port} connection
     * @param {string | number} connectionId
     * @param {string | number} tabId
     */
    _addConnectionOnDisconnectListeners(connection, connectionId, tabId) {
        connection.onDisconnect.addListener(() => {
            delete this.connections[tabId][connectionId];
        });
    }

    _tryGetCurrentTab() {
        return new Promise(resolve => {
            if (!this._canAccessTabs()) {
                return resolve(this.nydusTab ?? -1);
            }
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
                const tabId = tabs.length < 1 ? chrome.devtools.inspectedWindow.tabId : tabs[0].id;
                resolve(tabId ?? -1);
            });
        });
    }

    /**
     * @param {number} tabId
     * @param {NydusConnection} nydusConnection
     */
    _addConnectionToPool(tabId, nydusConnection) {
        nydusConnection.tabId = tabId;
        if (!this.connections[tabId]) this.connections[tabId] = {};
        this.connections[tabId][nydusConnection.id] = nydusConnection;
    }

    /**
     * @param {NydusConnection} nydusConnection
     * @param {OnMessageCallback} onMessage
     */
    _doHostHandshake(nydusConnection, onMessage, isBackground) {
        chrome.runtime.onConnect.addListener(
            function startHandshake(/** @type chrome.runtime.Port */ connection) {
                if (connection.name !== nydusConnection.id) return;
                nydusConnection.tabId = isBackground ? -1 : connection?.sender?.tab?.id ?? this.nydusTab;
                this._handleClientHandshake(connection, nydusConnection);

                if (onMessage) {
                    connection.onMessage.addListener(onMessage);
                }
                this._addConnectionOnDisconnectListeners(
                    connection,
                    nydusConnection.id.toString(),
                    nydusConnection.tabId,
                );
            }.bind(this),
        );
    }

    _canAccessTabs() {
        return typeof chrome.tabs !== 'undefined';
    }

    /**
     * @param {{type: string;id: any; tabId: number;}} message
     * @param {NydusConnection} nydusConnection
     */
    _handleConnectionHandshakeMessage(message, nydusConnection) {
        if (message.type !== NYDUS_CONNECTION_HANDSHAKE) return;

        const tabId = message.tabId;
        nydusConnection.tabId = tabId;
        nydusConnection.ready = true;

        this._doOnConnect(nydusConnection.connection);
        this._readyCheck();
    }

    /**
     * @param {chrome.runtime.Port} connection
     * @param {NydusConnection} nydusConnection
     */
    _handleClientHandshake(connection, nydusConnection) {
        nydusConnection.connection = connection;
        nydusConnection.ready = true;
        this._addConnectionToPool(nydusConnection.tabId, nydusConnection);
        this._sendHandshake(nydusConnection);
        this._doOnConnect(connection);
        this._readyCheck();
    }

    /**
     * Trigger the onConnect callback of the Nydus instance
     *
     * @param {chrome.runtime.Port} connection
     */
    _doOnConnect(connection) {
        if (this.onConnect) {
            this.onConnect(this, connection);
        }
    }

    /**
     * @param {NydusConnection} nydusConnection
     */
    _sendHandshake(nydusConnection) {
        const connectionInstance = this.connections[nydusConnection.tabId][nydusConnection.id];
        connectionInstance.connection?.postMessage({
            type: NYDUS_CONNECTION_HANDSHAKE,
            id: connectionInstance.id,
            tabId: nydusConnection.tabId,
        });
    }

    async _readyCheck() {
        if (await this._requirementsFulfilled()) {
            // Resolve the whenReady promise for those listening for it
            this._whenReadyResolver(this);
            this._doOnReady();
        }
    }

    /**
     * Trigger onReady, and pass the nydus instance to it
     * */
    _doOnReady() {
        if (this.ready) return; // If already was ready, don't re-trigger

        this.ready = true;
        if (this.onReady) this.onReady(this);
    }

    _getConnectionsFlat() {
        let connections = [];
        for (const connPool of Object.values(this.connections)) {
            for (const conn of Object.values(connPool)) {
                connections.push(conn);
            }
        }

        return connections;
    }

    async _requirementsFulfilled() {
        // Check that all required connections are built and ready
        const connectionsFlat = this._getConnectionsFlat();
        return connectionsFlat.every(conn => conn.ready);
    }
}

/**
 * @returns {Promise<import('custom-elements-manifest/schema').Package | null>}
 * */
async function fetchManifest() {
    try {
        const origin = window.location.origin;
        const manifest = await fetch(origin + '/custom-elements.json')
            .then(res => {
                if (res.status >= 200 && res.status < 300) {
                    return Promise.resolve(res);
                } else {
                    return Promise.reject(res.status.toString());
                }
            })
            .catch(err => console.warn('[WebComponentDevTools]: Could not find custom-elements.json:', err));
        return manifest ? await manifest.json() : null;
    } catch (err) {
        return null;
    }
}

/**
 * @param {import('custom-elements-manifest/schema').Package} manifest
 */
function parseElementDeclarationMap(manifest) {
    /** @type Object.<String, DevToolsElement> */
    const declarationMap = {};
    const elementDeclarations = getCustomElementDeclarations(manifest);

    for (const elementDeclaration of elementDeclarations) {
        declarationMap[elementDeclaration.tagName] = {
            name: elementDeclaration.name,
            tagName: getTagName(elementDeclaration),
            parentClass: elementDeclaration.superclass,
            attributes: elementDeclaration.attributes ?? [],
            properties: getElementProperties(elementDeclaration) ?? [],
            events: elementDeclaration.events ?? [],
            methods: getElementMethods(elementDeclaration),
        };
    }
    return declarationMap;
}

/**
 * @param {import("custom-elements-manifest/schema").Package} manifest
 * @returns {Array<import('custom-elements-manifest/schema').CustomElement>}
 */
function getCustomElementDeclarations(manifest) {
    return manifest.modules.reduce(
        (coll, manifestModule) => [
            ...coll,
            ...manifestModule.declarations.filter(dec => isClassDeclaration(dec) && isCustomElementDeclaration(dec)),
        ],
        [],
    );
}

/**
 * @param {import('custom-elements-manifest/schema').CustomElement} customElement
 *
 * @returns { Array<import('custom-elements-manifest/schema').ClassMember> } methods
 */
function getElementMethods(customElement) {
    return customElement.members?.filter(isMethodMember);
}

/**
 * @param {import("custom-elements-manifest/schema").CustomElement} customElement
 *
 * @returns { Array<import('custom-elements-manifest/schema').ClassField> } properties
 */
function getElementProperties(customElement) {
    return /** @type Array<import('custom-elements-manifest/schema').ClassField> */ (
        customElement.members?.filter(isFieldMember)
    );
}

/**
 * @param {import('custom-elements-manifest/schema').ClassMember} classMember
 */
function isMethodMember(classMember) {
    return classMember.kind === 'method';
}

/**
 * @param {import('custom-elements-manifest/schema').ClassMember} classMember
 */
function isFieldMember(classMember) {
    return classMember.kind === 'field';
}

/**
 * @param {import('custom-elements-manifest/schema').Declaration} customElement
 */
function isCustomElementDeclaration(customElement) {
    return /** @type import('custom-elements-manifest/schema').CustomElement */ (customElement).customElement;
}

/**
 * @param {import('custom-elements-manifest/schema').Declaration} declaration
 */
function isClassDeclaration(declaration) {
    return declaration.kind === 'class';
}

/**
 * @param {import('custom-elements-manifest/schema').CustomElement} moduleDeclaration
 */
function getTagName(moduleDeclaration) {
    return moduleDeclaration.tagName;
}

async function mapCustomElementManifestData() {
    const manifest = await fetchManifest();
    if (!manifest || !manifest.modules) return {};

    const parsed = parseElementDeclarationMap(manifest);
    return parsed;
}

let nydus;
let customElementManifestData;

loadCustomElementManifestData();

async function loadCustomElementManifestData() {
    customElementManifestData = await mapCustomElementManifestData();
}

function initNydus() {
    nydus = buildNydus({
        connections: [
            {
                id: CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT,
                onMessage: onNydusMessage,
                host: true,
            },
            {
                id: CONNECTION_CHANNELS.DEVTOOLS_BACKGROUND_CONTENT,
                onMessage: onNydusMessage,
                host: false,
            },
        ],
    });
}

// This extra channel is used for when some of the sessions have
// expired, but others haven't. For example refreshing with devtools open
chrome.runtime.onMessage.addListener(message => {
    if (message.type === MESSAGE_TYPE.REFRESH) {
        chrome.runtime.sendMessage({ type: MESSAGE_TYPE.REFRESH, tabId: message.tabId });
        loadCustomElementManifestData();
    }
});

// This "channel" is used to communicate with dom events and their mutation observers
document.addEventListener(MUTATION_EVENT, (/** @type {CustomEvent} */ e) => {
    if (!nydus.ready) return;
    switch (e.detail.action) {
        case 'QUERY':
            doQuery();
            break;
        case 'RESELECT':
            doSelect(e.detail.target);
            break;
    }
});

// This "channel" is used to communicate with dom events and other interaction
document.addEventListener(DOM_CREATED_EVENT, (/** @type CustomEvent */ e) => {
    if (!nydus.ready) return;
    switch (e.detail.action) {
        case "SELECT":
            doSelect(e.detail.target);
            break;
        case "EVENT":
            triggerEvent(e.detail.eventData);
            break;
    }
});

initNydus();

/**
 * @param {any} message
 */
function onNydusMessage(message) {
    switch (message.type) {
        case MESSAGE_TYPE.LOG:
            if (typeof message.log === 'object') console.log('', message.log);
            else console.log(message.log);
            break;
        case MESSAGE_TYPE.LOG_OBJECT:
            console.log(message.log, message.data);
            break;
        case MESSAGE_TYPE.QUERY:
            doQuery();
            break;
        case MESSAGE_TYPE.PANEL_OPENED:
            doOnPanelOpen(message.tabId);
            break;
        case MESSAGE_TYPE.HIGHLIGHT:
            doHighlight(message);
            break;
        case MESSAGE_TYPE.SELECT:
            doSelect(message);
            break;
        case MESSAGE_TYPE.REFRESH:
            doRefresh(message.tabId);
            break;
        case MESSAGE_TYPE.UPDATE_PROPERTY:
            doPropertyUpdate(message);
            break;
        case MESSAGE_TYPE.UPDATE_ATTRIBUTE:
            doAttributeUpdate(message);
            break;
        case MESSAGE_TYPE.INSPECT:
            doInspect();
            break;
        case MESSAGE_TYPE.CALL_FUNCTION:
            doCallFunction(message);
            break;
    }
}

/**
 * @param {any} message
 */
function doCallFunction(message) {
    document.dispatchEvent(
        new CustomEvent(FUNCTION_CALL_REQUEST, {
            detail: message,
        }),
    );
}

/**
 * @param {any} message
 * */
function doPropertyUpdate(message) {
    document.dispatchEvent(
        new CustomEvent(UPDATE_PROPERTY_REQUEST, {
            detail: message,
        }),
    );
}

/**
 * @param {any} message
 */
function doAttributeUpdate(message) {
    document.dispatchEvent(
        new CustomEvent(UPDATE_ATTRIBUTE_REQUEST, {
            detail: message,
        }),
    );
}

function doInspect() {
    const selectResponse = waitForDomMessageResponse(SELECT_RESULT);
    document.dispatchEvent(new CustomEvent(INSPECT_REQUEST));

    selectResponse.then(res => {
        nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
            type: MESSAGE_TYPE.SELECT_RESULT,
            data: res.detail,
        });
    });
}

/**
 * @param {any} tabId
 */
function doOnPanelOpen(tabId) {
    nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
        type: MESSAGE_TYPE.PANEL_OPENED,
        tabId,
    });
}

/**
 * @param {any} tabId
 */
function doRefresh(tabId) {
    nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
        type: MESSAGE_TYPE.REFRESH,
        tabId,
    });
}

function doQuery() {
    const queryResponse = waitForDomMessageResponse(QUERY_RESULT);
    document.dispatchEvent(new CustomEvent(QUERY_REQUEST));

    queryResponse.then(res => {
        nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
            type: MESSAGE_TYPE.QUERY_RESULT,
            data: res.detail,
        });
    });
}

/**
 * @param {{ index: any; }} message
 */
function doHighlight(message) {
    document.dispatchEvent(
        new CustomEvent(HIGHLIGHT_ELEMENT, {
            detail: { index: message.index },
        }),
    );
}

/**
 * @param {any} message
 */
function doSelect(message) {
    const selectResponse = waitForDomMessageResponse(SELECT_RESULT);
    /** @type DevToolsElement */
    let eventData = message;
    if (customElementManifestData[message.tagName]) {
        eventData = { ...eventData, ...customElementManifestData[message.tagName] };
    }
    document.dispatchEvent(
        new CustomEvent(SELECT_REQUEST, {
            detail: eventData,
        }),
    );

    selectResponse.then(res => {
        /** @type DevToolsElement */
        const elementData = res.detail;
        nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
            type: MESSAGE_TYPE.SELECT_RESULT,
            data: elementData,
        });
    });
}

function triggerEvent(eventData) {
    nydus.message(CONNECTION_CHANNELS.DEVTOOLS_PANEL_TO_CONTENT, {
        type: MESSAGE_TYPE.TRIGGER_EVENT,
        eventData
    });
}

/**
 * @param {string} eventName
 */
function waitForDomMessageResponse(eventName) {
    return new Promise((resolve, reject) => {
        document.addEventListener(
            eventName,
            e => {
                resolve(e);
            },
            { once: true },
        );
    });
}

function injectScript() {
    // Inject devtools DOM scripts
    const script = document.createElement("script");

    script.innerHTML = `
        ${crawlerInject}
        ${SpotlightBorder.toString()}
    `;

    document.head.appendChild(script);
}

injectScript();
