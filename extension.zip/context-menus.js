import { C as CONNECTION_CHANNELS, M as MESSAGE_TYPE, b as buildNydus } from './message-types-3bf354c3.js';

let nydus;

const contextMenuOptions = {
    title: "Inspect Web Component",
    type: "normal",
    id: "wc-devtoolsinspect-web-component",
    documentUrlPatterns: ["<all_urls>"],
    contexts: ["all"],
    onclick: onWebComponentInspect,
    visible: true, // True if page has web components
};

chrome.contextMenus.removeAll();
chrome.contextMenus.create(contextMenuOptions);

/**
 * @param {chrome.contextMenus.OnClickData} info
 * @param {chrome.tabs.Tab} tab
 */
function onWebComponentInspect(info, tab) {
    nydus.message(CONNECTION_CHANNELS.DEVTOOLS_CONTEXT_MENU_TO_BACKGROUND, { type: MESSAGE_TYPE.INSPECT });
}

function createContextMenusNydus() {
    nydus = buildNydus({
        connections: [
            {
                id: CONNECTION_CHANNELS.DEVTOOLS_CONTEXT_MENU_TO_BACKGROUND,
                host: false,
                isBackground: true,
            },
        ],
    });
}

createContextMenusNydus();
